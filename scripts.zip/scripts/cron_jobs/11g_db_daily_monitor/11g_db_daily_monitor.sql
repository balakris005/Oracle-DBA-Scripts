-- +--------------------------------------------------------------------------------------+
-- | Script   : 11g_db_daily_monitor.sql							  		|
-- | Created  : Bala 						       		  	|
-- |      On  : Oct/09/2013								  			|
-- | Modified : Mar/03/2014							  				|
-- | PURPOSE  : Provides a detailed AWR based health check report for the Last 24 Hours	|
-- |            (in HTML format can be edited in Excel)	 				  	|
-- |            				                               		  		|
-- | USAGE    :                                                                		|
-- |                                                                           		|
-- |    sqlplus -s uid/pwd@database @11g_db_daily_monitor.sql AWR_MyDB.html        		|
-- |    Assumptions:									  			|
-- |    		   The database has SGA/PGA (Minimun 5 GB Each)			  		|
-- |			   Optimizer Stats History got purged after 30 days (Doc ID 1055547.1)	|
-- |			   System Stats, Dictionary Stats, Fixed Obj stats are available  	| 
-- |											  				|
-- +--------------------------------------------------------------------------------------+

-- +----------------------------------------------------------------------------+
-- |                   GATHER DATABASE REPORT INFORMATION                       |
-- +----------------------------------------------------------------------------+

define report_file='&1'

alter session set optimizer_mode=ALL_ROWS;
alter session set OPTIMIZER_INDEX_COST_ADJ=1000;
alter session set OPTIMIZER_INDEX_CACHING=0;

COLUMN tdate NEW_VALUE _date NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY') tdate FROM dual;

COLUMN time NEW_VALUE _time NOPRINT
SELECT TO_CHAR(SYSDATE,'HH24:MI:SS') time FROM dual;

COLUMN date_time NEW_VALUE _date_time NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY HH24:MI:SS') date_time FROM dual;

COLUMN date_time_timezone NEW_VALUE _date_time_timezone NOPRINT
SELECT TO_CHAR(systimestamp, 'Mon DD, YYYY (') || TRIM(TO_CHAR(systimestamp, 'Day')) || TO_CHAR(systimestamp, ') "at" HH:MI:SS AM') || TO_CHAR(systimestamp, ' "in Timezone" TZR') date_time_timezone
FROM dual;

COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD') spool_time FROM dual;

COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;

COLUMN dbid NEW_VALUE _dbid NOPRINT
SELECT dbid dbid FROM v$database;

COLUMN platform_id NEW_VALUE _platform_id NOPRINT
SELECT platform_id platform_id FROM v$database;

COLUMN platform_name NEW_VALUE _platform_name NOPRINT
SELECT platform_name platform_name FROM v$database;

COLUMN global_name NEW_VALUE _global_name NOPRINT
SELECT global_name global_name FROM global_name;

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
SELECT value blocksize FROM v$parameter WHERE name='db_block_size';

COLUMN startup_time NEW_VALUE _startup_time NOPRINT
SELECT TO_CHAR(startup_time, 'MON/DD/YYYY HH24:MI:SS') startup_time FROM v$instance;

COLUMN host_name NEW_VALUE _host_name NOPRINT
SELECT host_name host_name FROM v$instance;

COLUMN instance_name NEW_VALUE _instance_name NOPRINT
SELECT instance_name instance_name FROM v$instance;

COLUMN instance_number NEW_VALUE _instance_number NOPRINT
SELECT instance_number instance_number FROM v$instance;

COLUMN thread_number NEW_VALUE _thread_number NOPRINT
SELECT thread# thread_number FROM v$instance;

COLUMN cluster_database NEW_VALUE _cluster_database NOPRINT
SELECT value cluster_database FROM v$parameter WHERE name='cluster_database';

COLUMN cluster_database_instances NEW_VALUE _cluster_database_instances NOPRINT
SELECT value cluster_database_instances FROM v$parameter WHERE name='cluster_database_instances';

COLUMN reportRunUser NEW_VALUE _reportRunUser NOPRINT
SELECT 'Bala (KPIT-DBA)' reportRunUser FROM dual;

COLUMN node_1 NEW_VALUE _node_1 NOPRINT
SELECT instance_name||':'||host_name node_1 FROM gv$instance where inst_id = 1;

COLUMN node_2 NEW_VALUE _node_2 NOPRINT
SELECT instance_name||':'||host_name node_2 FROM gv$instance where inst_id = 2;

COLUMN node_3 NEW_VALUE _node_3 NOPRINT
SELECT instance_name||':'||host_name node_3 FROM gv$instance where inst_id = 3;

COLUMN node_4 NEW_VALUE _node_4 NOPRINT
SELECT instance_name||':'||host_name node_4 FROM gv$instance where inst_id = 4;

set term off;
set termout       off
set echo          off
set feedback      off
set heading       off
set verify        off
set wrap          on
set trimspool     on
set serveroutput  on
set escape        on

set pagesize 50000
set linesize 500
set long     2000000000

set heading on;

set markup html on spool on preformat off entmap on -
head ' -
  <title>Database Report</title> -
  <style type="text/css"> -
    body              {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    p                 {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    table,tr,td       {font:9pt Arial,Helvetica,sans-serif; color:Black; background:#C0C0C0; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;} -
    th                {font:bold 9pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;} -
    h1                {font:bold 12pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;} -
    h2                {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; margin-bottom:0pt;} -
    a                 {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.link            {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLink          {font:9pt Arial,Helvetica,sans-serif; color:#663300; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkBlue      {font:9pt Arial,Helvetica,sans-serif; color:#0000ff; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkBlue  {font:9pt Arial,Helvetica,sans-serif; color:#000099; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkRed       {font:9pt Arial,Helvetica,sans-serif; color:#ff0000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkRed   {font:9pt Arial,Helvetica,sans-serif; color:#990000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkGreen     {font:9pt Arial,Helvetica,sans-serif; color:#00ff00; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkGreen {font:9pt Arial,Helvetica,sans-serif; color:#009900; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
  </style>' -
body   'BGCOLOR="#C0C0C0"' -
table  'WIDTH="90%" BORDER="1"' 

--spool &_global_name..html;
spool &report_file;

set markup html on entmap off;

--prompt <a name=top></a>

-- +============================================================================+
-- |                                                                            |
-- |        <<<<<     Database and Instance Information    >>>>>                |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>&_dbname - Daily Health Check Report (For the Last 24 Hours)</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                            - REPORT HEADER -                               |
-- +----------------------------------------------------------------------------+

prompt 
prompt <a name="top1"></a>

prompt <table width="90%" border="1"> -
<H2>Table of Contents</H2> -

prompt <div id="top_awr"> -
<ul> -
<li><a class="link" >DBA Review</a></li> -
<ol> -
<li><a class="link" href="#awr_global">Global AWR Report</a></li> -
<li><a class="link" href="#top_class_wait_events">Database (RAC/Non-RAC) - Top Event Class</a></li> -
<li><a class="link" href="#top_wait_events">Instance - Top Events</a></li> -
<li><a class="link" href="#wait_events">Application Objects - Event Activity</a></li> -
<li><a class="link" href="#top_cpu_jobs">Top Modules Consuming CPUs</a></li> -
<li><a class="link" href="#alert_log">Database Alerts</a></li> -
</o1> -
</div>
prompt <div id="iops"> -
<ul> -
<li><a class="link" >SYSADM Review -  IOPS Details</a></li> -
<ol> -
<li><a class="link" href="#iops_1">&_node_1</a></li> -
<li><a class="link" href="#iops_2">&_node_2</a></li> -
<li><a class="link" href="#iops_3">&_node_3</a></li> -
<li><a class="link" href="#iops_4">&_node_4</a></li> -
</o1> -
</div> -
<div id="awr"> -
<ul> -
<li><a class="link" >SYSDBA Review</a></li> -
<ol> -
<li><a class="link" href="#admn_1">Administrative</a></li> -
<li><a class="link" href="#app_2">Application</a></li> -
<li><a class="link" href="#crs_3">Cluster</a></li> -
<li><a class="link" href="#cmt_4">Commit</a></li> -
<li><a class="link" href="#con_5">Concurrency</a></li> -
<li><a class="link" href="#config_6">Configuration</a></li> -
<li><a class="link" href="#idle_7">Idle</a></li> -
<li><a class="link" href="#net_8">Network</a></li> -
<li><a class="link" href="#oth_9">Other</a></li> -
<li><a class="link" href="#sys_10">System I/O</a></li> -
<li><a class="link" href="#usr_11">User I/O</a></li> -
</o1> </div>
prompt <div id="long"> -
<ul> -
<li><a class="link" >Application DBA Review</a></li> -
<ol> -
<li><a class="link" href="#asa">Recommendations - Auto Segment Advisor (ASA)</a></li> -
<li><a class="link" href="#addm">Findings identified By Automatic Database Diagnostic Monitor (ADDM)</a></li> -
<li><a class="link" href="#stale">Application Objects With Stale Statistics</a></li> -
<li><a class="link" href="#more_than_aday">Jobs Running More Than a Day</a></li> -
<li><a class="link" href="#long_running">Long Running Jobs Needs Attention</a></li> -
<ul> -
<li><a class="link" href="#awr_sql_report">AWR SQL Report</a></li> -
<li><a class="link" href="#ash_report">ASH Report</a></li> -
<li><a class="link" href="#top_10">Dynamic Information for Top 50 Sessions</a></li> -
</u1> -
</div> -
<tr><th align="left" width="20%">Report Name</th><td width="80%"><tt>Database Monitoring Report (Hourly)</tt></td></tr> -
<tr><th align="left" width="20%">Run Date / Time / Timezone</th><td width="80%"><tt>&_date_time_timezone</tt></td></tr> -
<tr><th align="left" width="20%">Host Name</th><td width="80%"><tt>&_host_name</tt></td></tr> -
<tr><th align="left" width="20%">Database Name</th><td width="80%"><tt>&_dbname</tt></td></tr> -
<tr><th align="left" width="20%">Database ID</th><td width="80%"><tt>&_dbid</tt></td></tr> -
<tr><th align="left" width="20%">Global Database Name</th><td width="80%"><tt>&_global_name</tt></td></tr> -
<tr><th align="left" width="20%">Platform Name / ID</th><td width="80%"><tt>&_platform_name / &_platform_id</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database?</th><td width="80%"><tt>&_cluster_database</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database Instances</th><td width="80%"><tt>&_cluster_database_instances</tt></td></tr> -
<tr><th align="left" width="20%">Instance Name</th><td width="80%"><tt>&_instance_name</tt></td></tr> -
<tr><th align="left" width="20%">Instance Number</th><td width="80%"><tt>&_instance_number</tt></td></tr> -
<tr><th align="left" width="20%">Thread Number</th><td width="80%"><tt>&_thread_number</tt></td></tr> -
<tr><th align="left" width="20%">Database Startup Time</th><td width="80%"><tt>&_startup_time</tt></td></tr> -
<tr><th align="left" width="20%">Database Block Size</th><td width="80%"><tt>&_blocksize</tt></td></tr> -
<tr><th align="left" width="20%">Report Script Created By: </th><td width="80%"><tt>&_reportRunUser</tt></td></tr> -
</table>


-- +----------------------------------------------------------------------------+
-- |                             - Long Running Jobs Needing Attention -        |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="long_running"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Jobs Running For More Than One Hour </b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN INST_ID          FORMAT 99           HEADING 'Instance'           ENTMAP off
COLUMN SQL_ID           FORMAT a20          HEADING 'SQL ID'             ENTMAP off
COLUMN STATEMENT        FORMAT a80          HEADING 'SQL Statement'      ENTMAP off
COLUMN OSUSER           FORMAT a30          HEADING 'OS User'            ENTMAP off
COLUMN RUNT             FORMAT a20          HEADING 'Last Call (HH:MM:SS)' ENTMAP off

SELECT
    SQL_ID,
    INST_ID,
    OSUSER,
    USERNAME,
    MACHINE,
    SQL_TEXT,
    MAX (RUNT) RUNT
FROM (SELECT
          '<a href="#' || sql_id || '">' || sql_id || '</a>' SQL_ID,
          INST_ID,
          OSUSER,
          USERNAME,
          MACHINE,
          substr(SQL_TEXT,1,80) SQL_TEXT,
          RUNT
      FROM
          (
              SELECT
                  DISTINCT
                  SES.INST_ID,
                  ses.sql_id,
                  ses.OSUSER,
                  SES.USERNAME,
                  SES.MACHINE,
                  SQL.SQL_TEXT,
                  LTRIM (TO_CHAR (FLOOR (SES.LAST_CALL_ET / 3600),
                                  '09')) || ':' || LTRIM (TO_CHAR (FLOOR (MOD (SES.LAST_CALL_ET,
                                                                               3600) / 60),
                                                                   '09')) || ':' || LTRIM (TO_CHAR (MOD (SES.LAST_CALL_ET,
                                                                                                         60),
                                                                                                    '09')) RUNT
              FROM
                  gv$SESSION SES,
                  gv$SQL SQL
              WHERE
                  --SES.STATUS = 'ACTIVE'
                  SES.USERNAME IS NOT NULL AND
                  SES.AUDSID != USERENV ('SESSIONID') AND
                  SES.SQL_ADDRESS = SQL.ADDRESS AND
                  SES.SQL_HASH_VALUE = SQL.HASH_VALUE AND
                  FLOOR (SES.LAST_CALL_ET / 3600) >= 1 AND 
                  SES.USERNAME NOT IN    (
                	'CTXSYS',
                	'OUTLN',
                	'ORACLE',
                	'ANONYMOUS',
                	'DBSNMP',
                	'DIP',
                	'SYS',
                	'SYSMAN',
                	'SYSTEM',
                	'XDB',
                	'TSMSYS',
                	'WMSYS', 'REPORT_USER'
            		)
              ORDER BY runt DESC
          ))
GROUP BY
    SQL_ID,
    INST_ID,
    OSUSER,
    USERNAME,
    MACHINE,
    SQL_TEXT
ORDER BY RUNT DESC
;

SELECT/*+ FIRST_ROWS USE_NL(S,SQ,P) */ s.inst_id 
                                        inst_id, 
                                        s.sid 
                                        sid, 
                                        s.serial# 
                                        serial, 
                                        s.last_call_et 
                                        sec_running, 
                                        Nvl(s.username, '(oracle)') 
                                        AS username, 
To_char(s.logon_time, 'DD-MM-YYYY HH24:MI:SS') session_logon_time, 
s.machine, 
Nvl(s.osuser, 'n/a')                           AS osuser, 
Nvl(s.program, 'n/a')                          AS program, 
s.event, 
s.seconds_in_wait, 
s.sql_id                                       sql_id, 
sq.sql_text 
 FROM   gv$session s, 
        gv$sqlarea sq 
 WHERE  s.sql_id = sq.sql_id 
        AND s.inst_id = sq.inst_id 
        AND s.status = 'ACTIVE' 
        AND s.last_call_et > 3600
        AND s.paddr NOT IN (SELECT paddr 
                            FROM   gv$bgprocess 
                            WHERE  paddr != '00') 
        AND s.TYPE != 'BACKGROUND' 
        AND s.username NOT IN ( 'SYSTEM', 'SYS' ) 
        AND s.event != 'SQL*Net break/reset to client' ;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                             - Database Alert Logs - 			        |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="alert_log"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Alert Log</b></font><hr align="left" width="460">

SELECT
    inst_id,
    originating_timestamp,
    message_text
FROM TABLE (gv$ (CURSOR (SELECT
                             inst_id,
                             originating_timestamp,
                             message_text
                         FROM v$diag_alert_ext
                         WHERE
                             originating_timestamp > (SYSDATE - 1) AND
                             message_text LIKE '%ORA-%')))
ORDER BY
    inst_id,
    originating_timestamp;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                             - Long Running Jobs more than a day - 	        |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="more_than_aday"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Jobs Running For More Than a Day </b></font><hr align="left" width="460">

COLUMN cpu_per_day_seconds        FORMAT 999,999,999.99          HEADING 'CPU Per Day (Seconds)'            ENTMAP off
COLUMN cpu				    FORMAT 999,999,999.99          HEADING 'CPU Activity (Seconds)'           ENTMAP off

SELECT *
FROM
    (
        SELECT
            DISTINCT
            P.INST_ID,
            p.spid SPID,
            TO_CHAR (s.LOGON_TIME,
                     'DDMonYY HH24:MI') date_login,
            s.username,
            DECODE
            (
                NVL (p.background,
                     0),
                1,
                bg.description,
                s.program
            )
            program,
            ss.value / 100 CPU,
            physical_reads disk_io,
            (TRUNC (SYSDATE,
                    'J') - TRUNC (logon_time,
                                  'J')) days,
            ROUND ((ss.value / 100) / (DECODE
                                       (
                                           (TRUNC (SYSDATE,
                                                   'J') - TRUNC (logon_time,
                                                                 'J')),
                                           0,
                                           1,
                                           (TRUNC (SYSDATE,
                                                   'J') - TRUNC (logon_time,
                                                                 'J'))
                                       )),
                   2) cpu_per_day_seconds
        FROM
            gv$PROCESS p,
            gv$SESSION s,
            gv$SESSTAT ss,
            gv$SESS_IO si,
            gv$BGPROCESS bg
        WHERE
            p.inst_id = s.inst_id AND
            p.inst_id = ss.inst_id AND
            p.inst_id = si.inst_id AND
            s.username NOT IN ('SYS', 'DBSNMP') AND
            s.paddr = p.addr AND
            ss.sid = s.sid AND
            ss.statistic# = 12 AND
            si.sid = s.sid AND
            bg.paddr (+) = p.addr AND
            ROUND ((ss.value / 100),
                   0) > 10
        ORDER BY 9
    )
WHERE days >= 1
ORDER BY days DESC;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Wait Events on Database Objects               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="wait_events"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Wait Events For More Than Five Minutes On Application Objects</b></font><hr align="left" width="460">

COLUMN wait_time FORMAT 99999,999,999     HEADING 'Wait Time|(Seconds)'    ENTMAP off

SELECT *
FROM
    (
        SELECT
            ash.inst_id,
            obj.owner,
            obj.object_name,
            obj.object_type,
            ash.event,
            ROUND (SUM (ash.wait_time + ash.time_waited) / 1000000) wait_time
        FROM
            gv$active_session_history ash,
            dba_objects obj
        WHERE
            obj.OWNER NOT IN
            (
                'CTXSYS',
                'OUTLN',
                'ORACLE',
                'ANONYMOUS',
                'DBSNMP',
                'DIP',
                'SYS',
                'SYSMAN',
                'SYSTEM',
                'XDB',
                'TSMSYS',
                'WMSYS',
                'REPORT_USER'
            )
            AND
            ash.sample_time > (SYSDATE - 1440 / 1440) AND
            --    ash.sample_time > (SYSDATE - 1) AND
            ash.current_obj# = obj.OBJECT_ID AND
            ROUND (ash.wait_time + ash.time_waited) > 0
        GROUP BY
            ash.inst_id,
            obj.owner,
            obj.object_name,
            obj.object_type,
            ash.event
        ORDER BY 6 DESC
    )
WHERE WAIT_TIME > 300;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |            - Top Class AWR Wait Events	(Sample Measure time 10 seconds)|
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="top_class_wait_events"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database - Top Event Class</b></font><hr align="left" width="460">

COLUMN time_secs 		FORMAT 99999,999,999,999.99 	HEADING 'Activity (In Secs)'
COLUMN pct 			FORMAT 999.99               	HEADING 'Percent'     ENTMAP off
COLUMN wait_class       FORMAT a20          		HEADING 'Event Class' ENTMAP off

SELECT
    wait_class,
    SUM (time_secs) time_secs,
    SUM (pct) pct
FROM (SELECT
          wait_class,
          NAME,
          ROUND (time_secs,
                 2) time_secs,
          ROUND (time_secs * 100 / SUM (time_secs) OVER (),
                 2) pct
      FROM
          (
              SELECT /*+ parallel(a,4) */
                  NVL (wait_class,
                       'CPU') wait_class,
                  NVL (a.event,
                       'ON CPU') AS NAME,
                  COUNT (*) * 10 AS time_secs
              FROM dba_hist_active_sess_history a
              WHERE a.sample_time > SYSDATE - 1
              GROUP BY
                  wait_class,
                  a.event
              ORDER BY time_secs DESC
          ))
GROUP BY wait_class
ORDER BY time_secs DESC;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |               - Top AWR Wait Events	(Sample Measure time 10 seconds)      |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="top_wait_events"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Instance - Wait Event Details</b></font><hr align="left" width="460">

COLUMN time_secs 		FORMAT 99999,999,999,999.99 	HEADING 'Activity (In Secs)'
COLUMN pct 			FORMAT 999.99               	HEADING 'Percent'     ENTMAP off
COLUMN wait_class       FORMAT A20          		HEADING 'Event Class' ENTMAP off
COLUMN name 		FORMAT A30				HEADING 'Event'       ENTMAP OFF
COLUMN instance_number  					HEADING 'Instance'    ENTMAP OFF

SELECT
    instance_number,
    wait_class,
    name,
    SUM (time_secs) time_secs,
    SUM (pct) pct
FROM (SELECT
          instance_number,
          wait_class,
          NAME,
          ROUND (time_secs,
                 2) time_secs,
          ROUND (time_secs * 100 / SUM (time_secs) OVER (),
                 2) pct
      FROM
          (
              SELECT /*+ parallel(a,4) */
                  instance_number,
                  NVL (wait_class,
                       'CPU') wait_class,
                  NVL (a.event,
                       'ON CPU') AS NAME,
                  COUNT (*) * 10 AS time_secs
              FROM dba_hist_active_sess_history a
              WHERE a.sample_time > SYSDATE - 1
              GROUP BY
                  instance_number,
                  wait_class,
                  a.event
              ORDER BY time_secs DESC
          ))
GROUP BY
    instance_number,
    wait_class,
    name
ORDER BY
    instance_number,
    time_secs DESC;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Top Jobs consuming high CPUs                  |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="top_cpu_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top Jobs Consuming CPUs (Last 24 Hours)</b></font><hr align="left" width="460">

COLUMN wait_time FORMAT 99999,999,999   	HEADING 'Activity|(Seconds)'    ENTMAP off
COLUMN SQL_TEXT  FORMAT A4000 trunc 	HEADING 'SQL Statement'         ENTMAP off
COLUMN instanace_number                 	HEADING 'Instance'
COLUMN cnt_on_cpu					HEADING 'Activity (Count) On CPU'
COLUMN cnt_waiting				HEADING 'Activity (Count) on Others'

WITH
    query_text AS (SELECT
                       sql_id,
                       sql_text
                   FROM dba_hist_sqltext),
    session_details AS (SELECT *
                        FROM (SELECT
                                  sql_id,
                                  instance_number,
                                  module,
                                  action,
                                  cnt_on_cpu,
                                  cnt_waiting,
                                  DENSE_RANK () OVER (PARTITION BY instance_number ORDER BY cnt_on_cpu DESC) cpu_rnk,
                                  DENSE_RANK () OVER (PARTITION BY instance_number ORDER BY cnt_waiting DESC) wait_rnk
                              FROM
                                  (
                                      SELECT
                                          sql_id,
                                          instance_number,
                                          SUM (DECODE
                                               (
                                                   ash.session_state,
                                                   'ON CPU',
                                                   1,
                                                   0
                                               )) cnt_on_cpu,
                                          SUM (DECODE
                                               (
                                                   ash.session_state,
                                                   'WAITING',
                                                   1,
                                                   0
                                               )) cnt_waiting,
                                          module,
                                          action
                                      FROM DBA_HIST_ACTIVE_SESS_HISTORY ash
                                      WHERE sample_time > SYSDATE - 1
                                      GROUP BY
                                          sql_id,
                                          instance_number,
                                          module,
                                          action
                                      ORDER BY 3 DESC
                                  ))
                        WHERE
                            wait_rnk <= 20 OR
                            cpu_rnk <= 20
                        ORDER BY cpu_rnk ASC)
SELECT    
    s.instance_number,
    s.module,
    s.cnt_on_cpu,
    s.cnt_waiting,
    s.cpu_rnk,
    wait_rnk,
    q.sql_text
FROM
    session_details s,
    query_text q
WHERE
    s.sql_id = q.sql_id 
ORDER BY cpu_rnk ASC
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Dynamic Information for Top 10 Sessions       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="top_10"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Dynamic Information for Top 50 Sessions</b></font><hr align="left" width="460">

WITH
--#########################################################################
--# NAME
--#   USER_SESSION_SUM
--#
--# PURPOSE
--#   This view lists dynamic information for current sessions for the user
--#   who logged onto the database. The information includes basic session
--#   and degree of parallelism information, statistics on CPU and I/O
--#   usage, and temporary segment usage.
--#
--#   Statistics for parallel execution sessions are rolled up to the query
--#   coordinator. Hence, the view returns one row for each logged on
--#   session.
--#
--# DESCRIPTION
--#   Column          Description
--#   --------------  -----------------------------------------------------
--#   inst_id         Instance identifier from which the information was
--#                   obtained. This is applicable to Real Application
--#                   Clusters (RAC). For non-RAC databases, it is always 1.
--#   sid             Oracle session identifier.
--#   serial#         Oracle session serial number.
--#   username        Oracle user name.
--#   command_name    Command in progress.
--#   status          Status of the session.
--#   osuser          Operating system user name.
--#   spid            Operating system process identifier.
--#   machine         Operating system machine name.
--#   program         Operating system program name.
--#   logon_time      Time of logon.
--#   last_call_et    If the session STATUS is currently ACTIVE, then the
--#                   value represents the elapsed time in seconds since
--#                   the session has become active. If the session STATUS
--#                   is currently INACTIVE, then the value represents the
--#                   elapsed time in seconds since the session has become
--#                   inactive.
--#   req_degree      The degree of parallelism that was requested by the
--#                   user when the statement was issued and prior to any
--#                   resource, multi-user, or load balancing reductions.
--#   degree          The degree of parallelism being used.
--#   cpu_used        Amount of CPU time (in 10s of milliseconds) used from
--#                   the time a user call starts until it ends. If a user
--#                   call completes within 10 milliseconds, the start and
--#                   end user-call time are the same for purposes of this
--#                   statistics, and 0 milliseconds are added.
--#   blocks_read     Total number of data blocks read from buffer cache,
--#                   process private memory, or disk.
--#   blocks_written  Total number of data blocks written to disk.
--#   tempseg_blocks  Total number of temporary segment data blocks used
--#                   for sorting, hash, etc.
--#   sql_text        First thousand characters of the SQL statement that
--#                   is currently being executed. Newline characters are
--#                   removed.
--#
--# NOTES
--#
--# HISTORY
--#   2013-01-17 ernestc - Created.
--#
--#########################################################################
--#
--# Subquery to aggregate statistics for user sessions. Statistics are
--# aggregated up to the query coordinator for parallel execution.
--#
v_sesstat AS
(
  SELECT inst_id,
         sid,
         serial#,
         name,
         SUM(value) AS value
  FROM
  (
    SELECT v_session.inst_id,
           v_session.sid,
           v_session.serial#,
           v_statname.name,
           SUM(v_sesstat.value) AS value
    FROM   gv$session v_session
    INNER  JOIN gv$sesstat v_sesstat
    ON     v_sesstat.inst_id = v_session.inst_id
    AND    v_sesstat.sid = v_session.sid
    INNER  JOIN gv$statname v_statname
    ON     v_statname.inst_id = v_sesstat.inst_id
    AND    v_statname.statistic# = v_sesstat.statistic#
    WHERE  v_statname.name IN
    (
      'CPU used by this session',
      'session logical reads',
      'physical reads',
      'physical writes'
    )
    GROUP  BY
           v_session.inst_id,
           v_session.sid,
           v_session.serial#,
           v_statname.name
    --#
    UNION  ALL
    --#
    SELECT v_px_sesstat.qcinst_id AS inst_id,
           v_px_sesstat.qcsid AS sid,
           v_px_sesstat.qcserial# AS serial#,
           v_statname.name,
           SUM(v_px_sesstat.value) AS value
    FROM   gv$px_sesstat v_px_sesstat
    INNER  JOIN gv$statname v_statname
    ON     v_statname.inst_id = v_px_sesstat.inst_id
    AND    v_statname.statistic# = v_px_sesstat.statistic#
    WHERE  v_statname.name IN
    (
      'CPU used by this session',
      'session logical reads',
      'physical reads',
      'physical writes'
    )
    GROUP  BY
           v_px_sesstat.qcinst_id,
           v_px_sesstat.qcsid,
           v_px_sesstat.qcserial#,
           v_statname.name
  )
  GROUP  BY
         inst_id,
         sid,
         serial#,
         name
),
--#
--# Subquery to find the requested and used degree of parallelism.
--#
v_px_degree AS
(
  SELECT qcinst_id AS inst_id,
         qcsid AS sid,
         qcserial# AS serial#,
         MAX(degree) AS degree,
         MAX(req_degree) AS req_degree
  FROM   gv$px_session
  GROUP  BY
         qcinst_id,
         qcsid,
         qcserial#
),
--#
--# Subquery to aggregate temporary segment usage for user sessions.
--# Statistics are aggregated up to the query coordinator for parallel
--# execution.
--#
v_tempseg_usage AS
(
  SELECT inst_id,
         sid,
         serial#,
         SUM(blocks) AS blocks
  FROM
  (
    SELECT v_session.inst_id,
           v_session.sid,
           v_session.serial#,
           SUM(v_tempseg_usage.blocks) AS blocks
    FROM   gv$session v_session
    INNER  JOIN gv$tempseg_usage v_tempseg_usage
    ON     v_tempseg_usage.inst_id = v_session.inst_id
    AND    v_tempseg_usage.session_addr = v_session.saddr
    GROUP  BY
           v_session.inst_id,
           v_session.sid,
           v_session.serial#
    --#
    UNION  ALL
    --#
    SELECT v_px_session.qcinst_id,
           v_px_session.qcsid,
           v_px_session.qcserial#,
           SUM(v_tempseg_usage.blocks) AS blocks
    FROM   gv$px_session v_px_session
    INNER  JOIN gv$tempseg_usage v_tempseg_usage
    ON     v_tempseg_usage.inst_id = v_px_session.inst_id
    AND    v_tempseg_usage.session_addr = v_px_session.saddr
    GROUP  BY
           v_px_session.qcinst_id,
           v_px_session.qcsid,
           v_px_session.qcserial#
  )
  GROUP  BY
         inst_id,
         sid,
         serial#
),
user_session_sum AS
(
  SELECT v_session.inst_id,
         v_session.sid,
         v_session.serial#,
         v_session.username,
         audit_actions.name AS command_name,
         v_session.status,
         v_session.osuser,
         v_process.spid,
         v_session.machine,
         v_session.program,
         v_session.logon_time,
         v_session.last_call_et,
         --#
         --# Degree of parallelism information
         --#
         v_px_degree.req_degree,
         v_px_degree.degree,
         --#
         --# CPU usage information
         --#
         cpu_used.value AS cpu_used,
         --#
         --# I/O information
         --#
         NVL(logical_reads.value,0) + NVL(physical_reads.value,0) AS blocks_read,
         NVL(physical_writes.value,0) AS blocks_written,
         --#
         --# Temporary segment usage information
         --#
         NVL(v_tempseg_usage.blocks,0) AS tempseg_blocks,
         --#
         --# SQL information
         --#
         REPLACE(v_sqlarea.sql_text, CHR(10),'') AS sql_text
  --#
  --# Get session information.
  --#
  FROM   gv$session v_session
  --#
  --# Get audit action information.
  --#
  INNER  JOIN audit_actions audit_actions
  ON     audit_actions.action = v_session.command
  --#
  --# Get process information.
  --#
  LEFT   OUTER JOIN gv$process v_process
  ON     v_process.inst_id = v_session.inst_id
  AND    v_process.addr = v_session.paddr
  --#
  --# Get SQL information.
  --#
  LEFT   OUTER JOIN gv$sqlarea v_sqlarea
  ON     v_sqlarea.inst_id = v_session.inst_id
  AND    v_sqlarea.sql_id = v_session.sql_id
  AND    v_sqlarea.address = v_session.sql_address
  AND    v_sqlarea.hash_value = v_session.sql_hash_value
  --#
  --# Get degree of parallelism information.
  --#
  LEFT   OUTER JOIN v_px_degree v_px_degree
  ON     v_px_degree.inst_id = v_session.inst_id
  AND    v_px_degree.sid = v_session.sid
  AND    v_px_degree.serial# = v_session.serial#
  --#
  --# Get CPU used information.
  --#
  LEFT   OUTER JOIN v_sesstat cpu_used
  ON     cpu_used.inst_id = v_session.inst_id
  AND    cpu_used.sid = v_session.sid
  AND    cpu_used.serial# = v_session.serial#
  AND    cpu_used.name = 'CPU used by this session'
  --#
  --# Get logical reads information.
  --#
  LEFT   OUTER JOIN v_sesstat logical_reads
  ON     logical_reads.inst_id = v_session.inst_id
  AND    logical_reads.sid = v_session.sid
  AND    logical_reads.serial# = v_session.serial#
  AND    logical_reads.name = 'session logical reads'
  --#
  --# Get physical reads information.
  --#
  LEFT   OUTER JOIN v_sesstat physical_reads
  ON     physical_reads.inst_id = v_session.inst_id
  AND    physical_reads.sid = v_session.sid
  AND    physical_reads.serial# = v_session.serial#
  AND    physical_reads.name = 'physical reads'
  --#
  --# Get physical writes information.
  --#
  LEFT   OUTER JOIN v_sesstat physical_writes
  ON     physical_writes.inst_id = v_session.inst_id
  AND    physical_writes.sid = v_session.sid
  AND    physical_writes.serial# = v_session.serial#
  AND    physical_writes.name = 'physical writes'
  --#
  --# Get temporary segment usage information.
  --#
  LEFT   OUTER JOIN v_tempseg_usage v_tempseg_usage
  ON     v_tempseg_usage.inst_id = v_session.inst_id
  AND    v_tempseg_usage.sid = v_session.sid
  AND    v_tempseg_usage.serial# = v_session.serial#
  --#
  --# Additional predicates.
  --#
  WHERE  v_session.program NOT LIKE 'oracle%(%)'
  -- AND    v_session.username = SYS_CONTEXT('USERENV','SESSION_USER')
)
--#########################################################################
--# THE SQL ABOVE REPRESENTS THE USER SESSION SUMMARY VIEW. TO TEST THE   #
--# VIEW, SELECT FROM USER_SESSION_SUM BELOW.                             #
--#########################################################################
SELECT rank,
       FLOOR(last_call_et/86400) || 'd ' || 
         TO_CHAR(TO_DATE(MOD(last_call_et,86400) ,'sssss'),'hh24"h" mi"m" ss"s"') AS elapsed_time,
       inst_id,
       sid,
       serial#,
       username,
       sql_text,
       command_name,
       status,
       osuser,
       spid,
       machine,
       program,
       logon_time,
       last_call_et,
       req_degree,
       degree,
       cpu_used,
       blocks_read,
       blocks_written,
       tempseg_blocks
FROM
(
  SELECT inst_id,
         sid,
         serial#,
         username,
         command_name,
         status,
         osuser,
         spid,
         machine,
         program,
         logon_time,
         last_call_et,
         req_degree,
         degree,
         cpu_used,
         blocks_read,
         blocks_written,
         tempseg_blocks,
         sql_text,
         RANK() OVER (
           ORDER BY last_call_et DESC
         ) AS rank
  FROM   user_session_sum
  WHERE  status = 'ACTIVE'
)
WHERE rank <= 50
ORDER BY rank ASC
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Admin Wait Events    -                        |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="admn_1"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Administrative</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Administrative'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

-- +----------------------------------------------------------------------------+
-- |                            - IOPS Report NODE 1  	                    |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="iops_1"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Metrics - IOPS (&_node_1)</b></font><hr align="left" width="460">

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

SELECT
    begin_time "Day",
    CASE METRIC_NAME WHEN 'Physical Read Total Bytes Per Sec' THEN 'Read Total Bps' WHEN 'Physical Write Total Bytes Per Sec' THEN 
        'Write Total Bps' WHEN 'Redo Generated Per Sec' THEN 'Redo Bytes Per Sec' WHEN 'Physical Read Total IO Requests Per Sec' THEN 
        'Read IOPS' WHEN 'Physical Write Total IO Requests Per Sec' THEN 'Write IOPS' WHEN 'Redo Writes Per Sec' THEN 'Redo IOPS' WHEN 
        'Current OS Load' THEN 'OS Load' WHEN 'CPU Usage Per Sec' THEN 'DB CPU Usage Per Sec' WHEN 'Host CPU Utilization (%)' THEN 
        'Host CPU Util(%)' WHEN 'Network Traffic Volume Per Sec' THEN 'Network Bytes Per Sec' END IOPS,
    ROUND (NVL ("00",
                '')) "00",
    ROUND (NVL ("01",
                '')) "01",
    ROUND (NVL ("02",
                '')) "02",
    ROUND (NVL ("03",
                '')) "03",
    ROUND (NVL ("04",
                '')) "04",
    ROUND (NVL ("05",
                '')) "05",
    ROUND (NVL ("06",
                '')) "06",
    ROUND (NVL ("07",
                '')) "07",
    ROUND (NVL ("08",
                '')) "08",
    ROUND (NVL ("09",
                '')) "09",
    ROUND (NVL ("10",
                '')) "10",
    ROUND (NVL ("11",
                '')) "11",
    ROUND (NVL ("12",
                '')) "12",
    ROUND (NVL ("13",
                '')) "13",
    ROUND (NVL ("14",
                '')) "14",
    ROUND (NVL ("15",
                '')) "15",
    ROUND (NVL ("16",
                '')) "16",
    ROUND (NVL ("17",
                '')) "17",
    ROUND (NVL ("18",
                '')) "18",
    ROUND (NVL ("19",
                '')) "19",
    ROUND (NVL ("20",
                '')) "20",
    ROUND (NVL ("21",
                '')) "21",
    ROUND (NVL ("22",
                '')) "22",
    ROUND (NVL ("23",
                '')) "23"
FROM
    (
        SELECT
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy') begin_time,
            metric_name,
            TO_CHAR (BEGIN_TIME,
                     'HH24') dw,
            (AVG (m.average)) average
        FROM dba_hist_sysmetric_summary m
        WHERE
            BEGIN_TIME >= (SYSDATE - 1) AND
            INSTANCE_NUMBER = 1 AND
            METRIC_NAME IN
            (
                'Physical Read Total Bytes Per Sec',
                'Physical Write Total Bytes Per Sec',
                'Redo Generated Per Sec',
                'Physical Read Total IO Requests Per Sec',
                'Physical Write Total IO Requests Per Sec',
                'Redo Writes Per Sec',
                'Current OS Load',
                'CPU Usage Per Sec',
                'Host CPU Utilization (%)',
                'Network Traffic Volume Per Sec'
            )
        GROUP BY
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy'),
            METRIC_NAME,
            TO_CHAR (BEGIN_TIME,
                     'HH24')
        ORDER BY
            1,
            2
    )
        PIVOT
        (
            AVG (average)
            FOR dw
            IN
                (
                    '00' AS "00",
                    '01' AS "01",
                    '02' AS "02",
                    '03' AS "03",
                    '04' AS "04",
                    '05' AS "05",
                    '06' AS "06",
                    '07' AS "07",
                    '08' AS "08",
                    '09' AS "09",
                    '10' AS "10",
                    '11' AS "11",
                    '12' AS "12",
                    '13' AS "13",
                    '14' AS "14",
                    '15' AS "15",
                    '16' AS "16",
                    '17' AS "17",
                    '18' AS "18",
                    '19' AS "19",
                    '20' AS "20",
                    '21' AS "21",
                    '22' AS "22",
                    '23' AS "23"
                )
        )
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - IOPS Report NODE 2  	                    |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="iops_2"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Metrics - IOPS (&_node_2)</b></font><hr align="left" width="460">

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

SELECT
    begin_time "Day",
    CASE METRIC_NAME WHEN 'Physical Read Total Bytes Per Sec' THEN 'Read Total Bps' WHEN 'Physical Write Total Bytes Per Sec' THEN 
        'Write Total Bps' WHEN 'Redo Generated Per Sec' THEN 'Redo Bytes Per Sec' WHEN 'Physical Read Total IO Requests Per Sec' THEN 
        'Read IOPS' WHEN 'Physical Write Total IO Requests Per Sec' THEN 'Write IOPS' WHEN 'Redo Writes Per Sec' THEN 'Redo IOPS' WHEN 
        'Current OS Load' THEN 'OS Load' WHEN 'CPU Usage Per Sec' THEN 'DB CPU Usage Per Sec' WHEN 'Host CPU Utilization (%)' THEN 
        'Host CPU Util(%)' WHEN 'Network Traffic Volume Per Sec' THEN 'Network Bytes Per Sec' END IOPS,
    ROUND (NVL ("00",
                '')) "00",
    ROUND (NVL ("01",
                '')) "01",
    ROUND (NVL ("02",
                '')) "02",
    ROUND (NVL ("03",
                '')) "03",
    ROUND (NVL ("04",
                '')) "04",
    ROUND (NVL ("05",
                '')) "05",
    ROUND (NVL ("06",
                '')) "06",
    ROUND (NVL ("07",
                '')) "07",
    ROUND (NVL ("08",
                '')) "08",
    ROUND (NVL ("09",
                '')) "09",
    ROUND (NVL ("10",
                '')) "10",
    ROUND (NVL ("11",
                '')) "11",
    ROUND (NVL ("12",
                '')) "12",
    ROUND (NVL ("13",
                '')) "13",
    ROUND (NVL ("14",
                '')) "14",
    ROUND (NVL ("15",
                '')) "15",
    ROUND (NVL ("16",
                '')) "16",
    ROUND (NVL ("17",
                '')) "17",
    ROUND (NVL ("18",
                '')) "18",
    ROUND (NVL ("19",
                '')) "19",
    ROUND (NVL ("20",
                '')) "20",
    ROUND (NVL ("21",
                '')) "21",
    ROUND (NVL ("22",
                '')) "22",
    ROUND (NVL ("23",
                '')) "23"
FROM
    (
        SELECT
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy') begin_time,
            metric_name,
            TO_CHAR (BEGIN_TIME,
                     'HH24') dw,
            (AVG (m.average)) average
        FROM dba_hist_sysmetric_summary m
        WHERE
            BEGIN_TIME >= (SYSDATE - 1) AND
            INSTANCE_NUMBER = 2 AND
            METRIC_NAME IN
            (
                'Physical Read Total Bytes Per Sec',
                'Physical Write Total Bytes Per Sec',
                'Redo Generated Per Sec',
                'Physical Read Total IO Requests Per Sec',
                'Physical Write Total IO Requests Per Sec',
                'Redo Writes Per Sec',
                'Current OS Load',
                'CPU Usage Per Sec',
                'Host CPU Utilization (%)',
                'Network Traffic Volume Per Sec'
            )
        GROUP BY
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy'),
            METRIC_NAME,
            TO_CHAR (BEGIN_TIME,
                     'HH24')
        ORDER BY
            1,
            2
    )
        PIVOT
        (
            AVG (average)
            FOR dw
            IN
                (
                    '00' AS "00",
                    '01' AS "01",
                    '02' AS "02",
                    '03' AS "03",
                    '04' AS "04",
                    '05' AS "05",
                    '06' AS "06",
                    '07' AS "07",
                    '08' AS "08",
                    '09' AS "09",
                    '10' AS "10",
                    '11' AS "11",
                    '12' AS "12",
                    '13' AS "13",
                    '14' AS "14",
                    '15' AS "15",
                    '16' AS "16",
                    '17' AS "17",
                    '18' AS "18",
                    '19' AS "19",
                    '20' AS "20",
                    '21' AS "21",
                    '22' AS "22",
                    '23' AS "23"
                )
        )
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - IOPS Report NODE 3  	                    |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="iops_3"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Metrics - IOPS (&_node_3)</b></font><hr align="left" width="460">

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

SELECT
    begin_time "Day",
    CASE METRIC_NAME WHEN 'Physical Read Total Bytes Per Sec' THEN 'Read Total Bps' WHEN 'Physical Write Total Bytes Per Sec' THEN 
        'Write Total Bps' WHEN 'Redo Generated Per Sec' THEN 'Redo Bytes Per Sec' WHEN 'Physical Read Total IO Requests Per Sec' THEN 
        'Read IOPS' WHEN 'Physical Write Total IO Requests Per Sec' THEN 'Write IOPS' WHEN 'Redo Writes Per Sec' THEN 'Redo IOPS' WHEN 
        'Current OS Load' THEN 'OS Load' WHEN 'CPU Usage Per Sec' THEN 'DB CPU Usage Per Sec' WHEN 'Host CPU Utilization (%)' THEN 
        'Host CPU Util(%)' WHEN 'Network Traffic Volume Per Sec' THEN 'Network Bytes Per Sec' END IOPS,
    ROUND (NVL ("00",
                '')) "00",
    ROUND (NVL ("01",
                '')) "01",
    ROUND (NVL ("02",
                '')) "02",
    ROUND (NVL ("03",
                '')) "03",
    ROUND (NVL ("04",
                '')) "04",
    ROUND (NVL ("05",
                '')) "05",
    ROUND (NVL ("06",
                '')) "06",
    ROUND (NVL ("07",
                '')) "07",
    ROUND (NVL ("08",
                '')) "08",
    ROUND (NVL ("09",
                '')) "09",
    ROUND (NVL ("10",
                '')) "10",
    ROUND (NVL ("11",
                '')) "11",
    ROUND (NVL ("12",
                '')) "12",
    ROUND (NVL ("13",
                '')) "13",
    ROUND (NVL ("14",
                '')) "14",
    ROUND (NVL ("15",
                '')) "15",
    ROUND (NVL ("16",
                '')) "16",
    ROUND (NVL ("17",
                '')) "17",
    ROUND (NVL ("18",
                '')) "18",
    ROUND (NVL ("19",
                '')) "19",
    ROUND (NVL ("20",
                '')) "20",
    ROUND (NVL ("21",
                '')) "21",
    ROUND (NVL ("22",
                '')) "22",
    ROUND (NVL ("23",
                '')) "23"
FROM
    (
        SELECT
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy') begin_time,
            metric_name,
            TO_CHAR (BEGIN_TIME,
                     'HH24') dw,
            (AVG (m.average)) average
        FROM dba_hist_sysmetric_summary m
        WHERE
            BEGIN_TIME >= (SYSDATE - 1) AND
            INSTANCE_NUMBER = 3 AND
            METRIC_NAME IN
            (
                'Physical Read Total Bytes Per Sec',
                'Physical Write Total Bytes Per Sec',
                'Redo Generated Per Sec',
                'Physical Read Total IO Requests Per Sec',
                'Physical Write Total IO Requests Per Sec',
                'Redo Writes Per Sec',
                'Current OS Load',
                'CPU Usage Per Sec',
                'Host CPU Utilization (%)',
                'Network Traffic Volume Per Sec'
            )
        GROUP BY
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy'),
            METRIC_NAME,
            TO_CHAR (BEGIN_TIME,
                     'HH24')
        ORDER BY
            1,
            2
    )
        PIVOT
        (
            AVG (average)
            FOR dw
            IN
                (
                    '00' AS "00",
                    '01' AS "01",
                    '02' AS "02",
                    '03' AS "03",
                    '04' AS "04",
                    '05' AS "05",
                    '06' AS "06",
                    '07' AS "07",
                    '08' AS "08",
                    '09' AS "09",
                    '10' AS "10",
                    '11' AS "11",
                    '12' AS "12",
                    '13' AS "13",
                    '14' AS "14",
                    '15' AS "15",
                    '16' AS "16",
                    '17' AS "17",
                    '18' AS "18",
                    '19' AS "19",
                    '20' AS "20",
                    '21' AS "21",
                    '22' AS "22",
                    '23' AS "23"
                )
        )
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - IOPS Report NODE 4  	                    |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="iops_4"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Metrics - IOPS (&_node_4)</b></font><hr align="left" width="460">

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

SELECT
    begin_time "Day",
    CASE METRIC_NAME WHEN 'Physical Read Total Bytes Per Sec' THEN 'Read Total Bps' WHEN 'Physical Write Total Bytes Per Sec' THEN 
        'Write Total Bps' WHEN 'Redo Generated Per Sec' THEN 'Redo Bytes Per Sec' WHEN 'Physical Read Total IO Requests Per Sec' THEN 
        'Read IOPS' WHEN 'Physical Write Total IO Requests Per Sec' THEN 'Write IOPS' WHEN 'Redo Writes Per Sec' THEN 'Redo IOPS' WHEN 
        'Current OS Load' THEN 'OS Load' WHEN 'CPU Usage Per Sec' THEN 'DB CPU Usage Per Sec' WHEN 'Host CPU Utilization (%)' THEN 
        'Host CPU Util(%)' WHEN 'Network Traffic Volume Per Sec' THEN 'Network Bytes Per Sec' END IOPS,
    ROUND (NVL ("00",
                '')) "00",
    ROUND (NVL ("01",
                '')) "01",
    ROUND (NVL ("02",
                '')) "02",
    ROUND (NVL ("03",
                '')) "03",
    ROUND (NVL ("04",
                '')) "04",
    ROUND (NVL ("05",
                '')) "05",
    ROUND (NVL ("06",
                '')) "06",
    ROUND (NVL ("07",
                '')) "07",
    ROUND (NVL ("08",
                '')) "08",
    ROUND (NVL ("09",
                '')) "09",
    ROUND (NVL ("10",
                '')) "10",
    ROUND (NVL ("11",
                '')) "11",
    ROUND (NVL ("12",
                '')) "12",
    ROUND (NVL ("13",
                '')) "13",
    ROUND (NVL ("14",
                '')) "14",
    ROUND (NVL ("15",
                '')) "15",
    ROUND (NVL ("16",
                '')) "16",
    ROUND (NVL ("17",
                '')) "17",
    ROUND (NVL ("18",
                '')) "18",
    ROUND (NVL ("19",
                '')) "19",
    ROUND (NVL ("20",
                '')) "20",
    ROUND (NVL ("21",
                '')) "21",
    ROUND (NVL ("22",
                '')) "22",
    ROUND (NVL ("23",
                '')) "23"
FROM
    (
        SELECT
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy') begin_time,
            metric_name,
            TO_CHAR (BEGIN_TIME,
                     'HH24') dw,
            (AVG (m.average)) average
        FROM dba_hist_sysmetric_summary m
        WHERE
            BEGIN_TIME >= (SYSDATE - 1) AND
            INSTANCE_NUMBER = 4 AND
            METRIC_NAME IN
            (
                'Physical Read Total Bytes Per Sec',
                'Physical Write Total Bytes Per Sec',
                'Redo Generated Per Sec',
                'Physical Read Total IO Requests Per Sec',
                'Physical Write Total IO Requests Per Sec',
                'Redo Writes Per Sec',
                'Current OS Load',
                'CPU Usage Per Sec',
                'Host CPU Utilization (%)',
                'Network Traffic Volume Per Sec'
            )
        GROUP BY
            TO_CHAR (begin_time,
                     'DD-MON-RR : Dy'),
            METRIC_NAME,
            TO_CHAR (BEGIN_TIME,
                     'HH24')
        ORDER BY
            1,
            2
    )
        PIVOT
        (
            AVG (average)
            FOR dw
            IN
                (
                    '00' AS "00",
                    '01' AS "01",
                    '02' AS "02",
                    '03' AS "03",
                    '04' AS "04",
                    '05' AS "05",
                    '06' AS "06",
                    '07' AS "07",
                    '08' AS "08",
                    '09' AS "09",
                    '10' AS "10",
                    '11' AS "11",
                    '12' AS "12",
                    '13' AS "13",
                    '14' AS "14",
                    '15' AS "15",
                    '16' AS "16",
                    '17' AS "17",
                    '18' AS "18",
                    '19' AS "19",
                    '20' AS "20",
                    '21' AS "21",
                    '22' AS "22",
                    '23' AS "23"
                )
        )
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                            - Application Wait Events                       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="app_2"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Application</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Application'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Cluster Wait Events        -                  |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="crs_3"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Cluster</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Cluster'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

-- +----------------------------------------------------------------------------+
-- |                            - Commit Wait Events                            |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="cmt_4"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Commit</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Commit'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Concurrency Wait Events                       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="con_5"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Concurrency</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Concurrency'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Configuration Wait Events                       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="config_6"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Configuration</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Configuration'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Idle Wait Events                       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="idle_7"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Idle</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Idle'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Network Wait Events                       |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="net_8"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Network</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Network'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Other Wait Events                       	|
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="oth_9"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - Other</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'Other'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - Other Wait Events                       	|
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="sys_10"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - System I/O</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'System I/O'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - User I/O Wait Events                       	|
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="usr_11"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Wait Event - User I/O</b></font><hr align="left" width="460">

select 
to_char(snap_time,'DD-MON-RR : Dy') snap_time,
event_name,
to_char(avg(decode(to_char(snap_time,'HH24'),'00',wtdelta,null)),'999,999,999') " 00",
to_char(avg(decode(to_char(snap_time,'HH24'),'01',wtdelta,null)),'999,999,999') " 01",
to_char(avg(decode(to_char(snap_time,'HH24'),'02',wtdelta,null)),'999,999,999') " 02",
to_char(avg(decode(to_char(snap_time,'HH24'),'03',wtdelta,null)),'999,999,999') " 03",
to_char(avg(decode(to_char(snap_time,'HH24'),'04',wtdelta,null)),'999,999,999') " 04",
to_char(avg(decode(to_char(snap_time,'HH24'),'05',wtdelta,null)),'999,999,999') " 05",
to_char(avg(decode(to_char(snap_time,'HH24'),'06',wtdelta,null)),'999,999,999') " 06",
to_char(avg(decode(to_char(snap_time,'HH24'),'07',wtdelta,null)),'999,999,999') " 07",
to_char(avg(decode(to_char(snap_time,'HH24'),'08',wtdelta,null)),'999,999,999') " 08",
to_char(avg(decode(to_char(snap_time,'HH24'),'09',wtdelta,null)),'999,999,999') " 09",
to_char(avg(decode(to_char(snap_time,'HH24'),'10',wtdelta,null)),'999,999,999') " 10",
to_char(avg(decode(to_char(snap_time,'HH24'),'11',wtdelta,null)),'999,999,999') " 11",
to_char(avg(decode(to_char(snap_time,'HH24'),'12',wtdelta,null)),'999,999,999') " 12",
to_char(avg(decode(to_char(snap_time,'HH24'),'13',wtdelta,null)),'999,999,999') " 13",
to_char(avg(decode(to_char(snap_time,'HH24'),'14',wtdelta,null)),'999,999,999') " 14",
to_char(avg(decode(to_char(snap_time,'HH24'),'15',wtdelta,null)),'999,999,999') " 15",
to_char(avg(decode(to_char(snap_time,'HH24'),'16',wtdelta,null)),'999,999,999') " 16",
to_char(avg(decode(to_char(snap_time,'HH24'),'17',wtdelta,null)),'999,999,999') " 17",
to_char(avg(decode(to_char(snap_time,'HH24'),'18',wtdelta,null)),'999,999,999') " 18",
to_char(avg(decode(to_char(snap_time,'HH24'),'19',wtdelta,null)),'999,999,999') " 19",
to_char(avg(decode(to_char(snap_time,'HH24'),'20',wtdelta,null)),'999,999,999') " 20",
to_char(avg(decode(to_char(snap_time,'HH24'),'21',wtdelta,null)),'999,999,999') " 21",
to_char(avg(decode(to_char(snap_time,'HH24'),'22',wtdelta,null)),'999,999,999') " 22",
to_char(avg(decode(to_char(snap_time,'HH24'),'23',wtdelta,null)),'999,999,999') " 23"
FROM
(
WITH node_1 AS (SELECT
                         to_date(snaptime,'DD-MON-RR HH24') snap_time,
                         event_name,
                         wtdelta
                     FROM
                         (
                             SELECT
                                 snap_id,
                                 snaptime,
                                 event_name,
                                 therank,
                                 (waits - LAG
                                  (
                                      waits,
                                      1,
                                      0
                                  )
                                  OVER
                                  (
                                  PARTITION BY
                                      event_name
                                      ORDER BY snap_id
                                  )) wtdelta
                             FROM
                                 (
                                     SELECT
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24') snaptime,
                                         event_name,
                                         SUM (e.total_waits) waits,
                                         (RANK () OVER (ORDER BY s.snap_id)) therank
                                     FROM
                                         dba_hist_system_event e,
                                         dba_hist_snapshot s
                                     WHERE
                                         s.snap_id = e.snap_id AND
                                         s.end_interval_time > SYSDATE - 1  AND
                                         s.dbid = e.dbid AND
                                         s.instance_number = e.instance_number AND
                                         e.wait_class = 'User I/O'
                                     GROUP BY
                                         s.snap_id,
                                         TO_CHAR (s.begin_interval_time,
                                                  'DD-MON-RR HH24'),
                                         event_name
                                 )
                             ORDER BY
                                 snap_id,
                                 wtdelta DESC
                         )
                     WHERE therank > 1 and wtdelta > 0
                     )
SELECT A.SNAP_TIME snap_time,event_name,A.wtdelta
FROM NODE_1 A
ORDER BY 1
)
group by to_char(snap_time,'DD-MON-RR : Dy'),event_name
order by 1
;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - ADDM REPORT   -                               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="addm"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ADDM (Automated Database Diagnostics Monitor) Findings  </b></font><hr align="left" width="460">

SELECT
    type,
    message
FROM
    (
        SELECT
            type,
            message,
            COUNT (*) num
        FROM dba_advisor_findings
        WHERE
            TASK_ID IN (SELECT task_id
                        FROM DBA_ADVISOR_TASKS
                        WHERE TRUNC (created) = TRUNC (SYSDATE)) AND
            TYPE NOT IN ('INFORMATION', 'WARNING')
        GROUP BY
            type,
            message
        ORDER BY num DESC
    )
WHERE ROWNUM < 101;

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - ASA REPORT   -                               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="asa"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASA (Auto Segment Advisor) Findings  </b></font><hr align="left" width="460">

COLUMN c1 FORMAT A500  HEADING 'Command'    ENTMAP off;

SELECT
    tablespace_name,
    segment_name,
    segment_type,
    partition_name,
    recommendations,
    c1
FROM TABLE (dbms_space.asa_recommendations
            (
                'FALSE',
                'FALSE',
                'FALSE'
            ));

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

SET MARKUP HTML OFF;
SET HEADING OFF;

-- +----------------------------------------------------------------------------+
-- |                            - Stale Objects -                               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="stale"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Application Objects With Stale Statistics </b></font><hr align="left" width="460">

DECLARE
ObjList dbms_stats.ObjectTab;
BEGIN
DBMS_OUTPUT.PUT_LINE('<table width="90%" border="1">');
dbms_stats.gather_database_stats(objlist=>ObjList, options=>'LIST STALE');
FOR i in ObjList.FIRST..ObjList.LAST
LOOP
IF ObjList(i).ownname NOT IN (
        'CTXSYS',
        'OUTLN',
        'ORACLE',
        'ANONYMOUS',
        'DBSNMP',
        'DIP',
        'SYS',
        'SYSMAN',
        'SYSTEM',
        'XDB',
        'TSMSYS',
        'WMSYS',
        'REPORT_USER',
        'EXFSYS',
        'DMSYS',
        'MDSYS',
        'OLAPSYS',
        'SQLTXPLAIN',
        'IOTL_T'
    ) THEN
DBMS_OUTPUT.PUT_LINE('<tr><th align="left" width="80%">' || ObjList(i).ownname || '.' || ObjList(i).ObjName || ' ' || ObjList(i).ObjType || ' ' || ObjList(i).partname ||'</th></td></tr>');
ELSE NULL;
END IF;
END LOOP;
DBMS_OUTPUT.PUT_LINE('</table>');

END;
/

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - AWR SQL REPORT    -                           |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="awr_sql_report"></a>
prompt <TABLE>

WITH
    my_db AS (SELECT
                  s.dbid,
                  MIN (s.snap_id) begin_snap,
                  MAX (s.snap_id) end_snap
              FROM
                  dba_hist_snapshot s,
                  dba_hist_database_instance di
              WHERE
                  di.dbid = s.dbid AND
                  di.instance_number = s.instance_number AND
                  di.startup_time = s.startup_time AND
                  TRUNC (s.end_interval_time) = TRUNC (SYSDATE)
              GROUP BY s.dbid),
    long_running_jobs AS (SELECT
                              a.sql_id,
                              a.instance_number,
                              MIN (a.snap_id) start_snap_id,
                              MAX (a.snap_id) end_snap_id
                          FROM
                              dba_hist_sqlstat a,
                              dba_hist_snapshot b
                          WHERE
                              a.sql_id IN (SELECT
                                               DISTINCT
                                               ses.sql_id
                                           FROM
                                               gv$SESSION SES,
                                               gv$SQL SQL
                                           WHERE
                                               --SES.STATUS = 'ACTIVE'
                                               SES.USERNAME IS NOT NULL AND
                                               SES.AUDSID != USERENV ('SESSIONID') AND
                                               SES.SQL_ADDRESS = SQL.ADDRESS AND
                                               SES.SQL_HASH_VALUE = SQL.HASH_VALUE AND
                                               FLOOR (SES.LAST_CALL_ET / 3600) >= 1 AND
                                               SES.USERNAME NOT IN
                                               (
                                                   'CTXSYS',
                                                   'OUTLN',
                                                   'ORACLE',
                                                   'ANONYMOUS',
                                                   'DBSNMP',
                                                   'DIP',
                                                   'SYS',
                                                   'SYSMAN',
                                                   'SYSTEM',
                                                   'XDB',
                                                   'TSMSYS',
                                                   'WMSYS', 'REPORT_USER'
                                               )) AND
                              a.snap_id = b.snap_id AND
                              a.instance_number = b.instance_number AND
                              TRUNC (b.BEGIN_INTERVAL_TIME) = TRUNC (SYSDATE)
                          GROUP BY
                              a.sql_id,
                              a.instance_number)
SELECT *
FROM
    (
        SELECT tf.*
        FROM
            dba_hist_sqltext ht,
            long_running_jobs rj,
            my_db,
            TABLE (dbms_workload_repository.awr_sql_report_html
                   (
                       my_db.dbid,
                       rj.instance_number,
                       my_db.begin_snap,
                       my_db.end_snap,
                       ht.sql_id
                   )) tf
        WHERE ht.sql_id = rj.sql_id
    )
;
prompt </TABLE>
prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                            - AWR Global REPORT    -                        |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="awr_global"></a>
prompt <TABLE>

WITH my_db AS (SELECT
                   s.dbid,
                   MIN (s.snap_id) begin_snap,
                   MAX (s.snap_id) end_snap
               FROM
                   dba_hist_snapshot s,
                   dba_hist_database_instance di
               WHERE
                   di.dbid = s.dbid AND
                   di.instance_number = s.instance_number AND
                   di.startup_time = s.startup_time AND
                   s.end_interval_time BETWEEN SYSDATE - 1440 / 1440 AND SYSDATE - 1 / 1440
               GROUP BY s.dbid),
my_instance as (SELECT INSTANCE_NUMBER FROM V$INSTANCE)
SELECT *
FROM (SELECT tf.*
      FROM
          my_db,my_instance,
          TABLE (dbms_workload_repository.awr_global_report_html
                 (
                     my_db.dbid,
                     '',
                     my_db.begin_snap,
                     my_db.end_snap
                 )) tf)
;

prompt </TABLE>

prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

--spool off;
--EXIT;

-- +----------------------------------------------------------------------------+
-- |                            - ASH REPORT    -                               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="ash_report"></a>
prompt <TABLE>

WITH
    my_db AS (SELECT
                  s.dbid,
                  MIN (s.snap_id) begin_snap,
                  MAX (s.snap_id) end_snap
              FROM
                  dba_hist_snapshot s,
                  dba_hist_database_instance di
              WHERE
                  di.dbid = s.dbid AND
                  di.instance_number = s.instance_number AND
                  di.startup_time = s.startup_time AND
                  TRUNC (s.end_interval_time) = TRUNC (SYSDATE)
              GROUP BY s.dbid),
    long_running_jobs AS (SELECT
                              DISTINCT
                              a.instance_number,
                              MIN (a.snap_id) start_snap_id,
                              MAX (a.snap_id) end_snap_id
                          FROM
                              dba_hist_sqlstat a
                          WHERE
                              a.sql_id IN (SELECT
                                               DISTINCT
                                               ses.sql_id
                                           FROM
                                               gv$SESSION SES,
                                               gv$SQL SQL
                                           WHERE
                                               --SES.STATUS = 'ACTIVE'
                                               SES.USERNAME IS NOT NULL AND
                                               SES.AUDSID != USERENV ('SESSIONID') AND
                                               SES.SQL_ADDRESS = SQL.ADDRESS AND
                                               SES.SQL_HASH_VALUE = SQL.HASH_VALUE AND
                                               FLOOR (SES.LAST_CALL_ET / 3600) >= 1 AND
                                               SES.USERNAME NOT IN
                                               (
                                                   'CTXSYS',
                                                   'OUTLN',
                                                   'ORACLE',
                                                   'ANONYMOUS',
                                                   'DBSNMP',
                                                   'DIP',
                                                   'SYS',
                                                   'SYSMAN',
                                                   'SYSTEM',
                                                   'XDB',
                                                   'TSMSYS',
                                                   'WMSYS','REPORT_USER'
                                               )) 
                          GROUP BY a.instance_number
                          ORDER BY a.instance_number)
SELECT *
FROM (SELECT tf.*
      FROM
          long_running_jobs rj,
          my_db,
          TABLE (dbms_workload_repository.ash_report_html
                 (
                     my_db.dbid,
                     rj.instance_number,
                     SYSDATE - 120 / 1440,
                     SYSDATE - 1 / 1440
                 )) tf);
prompt </TABLE>
prompt <center>[<a class="noLink" href="#top1">Top</a>]</center><p>

spool off;

EXIT;
