#!/usr/bin/sh
#
# File name:
#       db_daily_monitor_new.sh
#
# Description:
#     Generates the following reports and sends e-mail notification to the listed recipients.
#        -  AWR Analysis (Cluster or Standalone Database)
#        -  Findings identified By Automatic Database Diagnostic Monitor (ADDM)
#        -  Recommendations - Auto Segment Advisor (ASA)
#          -  Wait Events on Application Objects
#          -  List of Long Running Jobs (Running more than an hour)
#        -  AWR SQL Report (For long running jobs)
#        -  ASH Report
#
# Customization:  Modify values for variables ORACLE_DB, WORKING_DIR, DIR, REPORT_FILE, connect user id/pwd
#
# Assumption:  The run user need to have the following privileges
#
# CONNECT,  RESOURCE,  SELECT_CATALOG_ROLE
# GRANT EXECUTE ON SYS.DBMS_WORKLOAD_REPOSITORY
# GRANT ADVISOR
# GRANT SELECT ANY DICTIONARY
# GRANT SELECT ANY TABLE
#
# Usage:  db_daily_monitor.sh $INSTANCE_NAME   (Valid Oracle 10g or above SID at $ORACLE_HOME/network/admin/tnsnames.ora)
#
# Created:
#       Jul/10/14 Bala - Created.
#
#######################################################

if [ $# != 1 ]; then
echo "Usage: $0 <INSTANCE_NAME>"
exit
fi

DB_NAME=$1; export DB_NAME

ORACLE_SID=ARIRPRA2; export ORACLE_SID

ORACLE_HOME=`grep -v "^[#]" /etc/oratab|grep $ORACLE_SID|cut -d: -f2`
export ORACLE_HOME

   TNS_ADMIN=$ORACLE_HOME/network/admin; export TNS_ADMIN
   ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data; export ORA_NLS33
   LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
   LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib; export LD_LIBRARY_PATH
   LIBPATH=$ORACLE_HOME/lib:/usr/lib:/lib; export LIBPATH
   PATH=$ORACLE_HOME/bin:$PATH; export PATH

#---------------------------------------# Exit on failure
failscript()
{
  if [ $1 -eq 0 ]
  then
    return 0
  fi
  # Error Handler

  typeset RETCODE=$1
  shift
  typeset MSG="$*"
  echo "$MSG"
  echo "$PRGMNAME: Could not complete successfully"
  exit $RETCODE
}
#--------------------------------------------- Usage function
usage () {
        echo
        echo "Usage: $PRGMNAME SID L"
        echo "where SID is target database"
        echo
        exit 1
}

DIR=/orabkup1/monitor
REPORT_FILE=$DIR/AWR_Daily_${DB_NAME}.html
. $DIR/ad_email.cfg
TARGET=$DIR/ad_email.cfg
cat $TARGET|egrep -v "^#|^$"|grep "$DB_NAME">/dev/null
if [[ $? -ne 0 ]]
then
echo
        failscript 1 "Error - $ORACLE_SID was not not found and please configure at ad_email.cfg"
echo
fi

export MAIL_USERS=`cat $TARGET|egrep $DB_NAME|cut -d: -f2`

cd $DIR

sqlplus -s report_user/report123@$DB_NAME  <<  .eof
echo "Connected...."
@/orabkup1/monitor/11g_db_daily_monitor.sql $REPORT_FILE
.eof


#cat $REPORT_FILE | uuencode $REPORT_FILE | mailx -s  "${DB_NAME} - Database Monitoring Report (Hourly)" $MAIL_USERS
cat $REPORT_FILE | uuencode $REPORT_FILE | mailx -s "ARIRPRA-${DB_NAME} - Database Monitoring Report" ORA-PROD-SUPPORT@kp.org,balakrishnan.jayasankar@kp.org
rm -f ${REPORT_FILE}
exit 0
