#!/bin/ksh
#set -x
#This script will purge old recyclebin objects records older than retention days passed as parameter
#report and alerts on-call and dispatch
# Author - Sanjoy
#Purge_recyclebin.ksh <<CDB>> <<instance name>> <<retention days>> <<pdbname>>
# Modify all Variables and CDB Name in email subject line
#call script example for CDB/PDB : Purge_recyclebin.ksh cdb123s1  cdb123s11 30 MASODWP01
#call script example for NON CDB : Purge_recyclebin.ksh "" cdb123s11 30 ""
## setup below veriables. Make sure to modify the path
## create log directory under script directory
## argument 2,3  <<instance name>> & <<retention days>> are mandatory
## pass epmty argument as ""

export ORACLE_CDB=$1
export ORACLE_SID=$2
export RET_DAYS=$3
export PDB_NAME=$4
export ORACLE_HOME=`grep -i $2 /etc/oratab |cut -f2 -d :| grep -iv '#' |sort -u`
export SCRIPT_DIR=/u01/app/oracle/dba/scripts
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export PATH=$PATH:$ORACLE_HOME/bin:/usr/bin:/etc:/usr/sbin:/usr/ucb:/usr/bin/X11:/sbin:/usr/local/bin:.
export maillist='balakrishnan.jayasankar@kp.org,vamsheedhar.r.katta@kp.org'
##,CTS_KP_ORACLE_DBAS-IREG@nsmtp.kp.org'
#export pagelist='CTS-KP-L15@nsmtp.kp.org'
#export CClist='kelly.m.lee@kp.org'
export DATE1=`TZ=aaa24 date +%d%b%Y`
export DATE2=`date +%d%b%Y`
LOG_FLE=$SCRIPT_DIR/log/Purge_recyclebin_$2_$(date +%m%d%H%M).log

if [ -z "$ORACLE_CDB" ]; then
echo 'is empty'
cd $SCRIPT_DIR
$ORACLE_HOME/bin/sqlplus -s /nolog <<EOF >>$LOG_FLE
connect / as sysdba
spool $SCRIPT_DIR/log/con_temp_${ORACLE_SID}.out
@$SCRIPT_DIR/recycleobj.sql $RET_DAYS;
spool off
spool $SCRIPT_DIR/log/dropobj.sql;
@$SCRIPT_DIR/gendrop.sql $RET_DAYS;
spool off
spool $SCRIPT_DIR/log/droplist.out
set feedback on
@$SCRIPT_DIR/log/dropobj.sql;
spool off

EOF
else
echo '$ORACLE_CDB is not empty'
cd $SCRIPT_DIR
$ORACLE_HOME/bin/sqlplus -s /nolog <<EOF >>$LOG_FLE
connect / as sysdba
spool $SCRIPT_DIR/log/con_temp_${ORACLE_SID}.out
set timing on
set echo on
show con_name
alter session set container=${PDB_NAME};
show pdbs
@$SCRIPT_DIR/recycleobj.sql $RET_DAYS;
spool off
spool $SCRIPT_DIR/log/dropobj.sql;
@$SCRIPT_DIR/gendrop.sql $RET_DAYS;
spool off
spool $SCRIPT_DIR/log/droplist.out
set feedback on
@$SCRIPT_DIR/log/dropobj.sql;
spool off
EOF
fi
echo 'Purging DB Recyclebin objects older than 31 days :' ${ORACLE_SID} | mailx -s "Recycle bin Purged older than 31 days - log - ${ORACLE_SID} "  -a $LOG_FLE $maillist
date
exit 0




------------------------

00 08 * * 6 /u01/app/oracle/dba/scripts/Purge_recyclebin.ksh CDB001I2 CDB001I21 31 SACRDST1R 2>&1 >/dev/null

-------------------

[oracle@szepdb123xm os]$ cat gendrop.sql
set lines 400
set pages 50000
set heading off;
set pagesize 0 heading off feedback off verify off echo off trimspool on
select 'purge table '||owner||'."'||OBJECT_NAME||'";'
from dba_recyclebin where type='TABLE' and to_date(droptime,'YYYY-MM-DD:HH24:MI:SS')<sysdate-&1 order by owner,object_name,type;