-- DROP TABLE system.LOGIN_LOG;
CREATE TABLE system.LOGIN_LOG
(
   USERNAME       VARCHAR2 (30 CHAR),
   SERVICE_NAME   VARCHAR2 (30 CHAR),
   DB_NAME        VARCHAR2 (30 CHAR),
   OSUSER         VARCHAR2 (30 CHAR),
   TERMINAL       VARCHAR2 (30 CHAR),
   IP             VARCHAR2 (64 CHAR),
   MODULE         VARCHAR2 (48 CHAR),
   LOGIN_TIME     TIMESTAMP
);

alter table system.LOGIN_LOG add HOST VARCHAR2(48); 

CREATE INDEX system.LOGIN_LOG_PK
   ON system.LOGIN_LOG (USERNAME, LOGIN_TIME);

CREATE OR REPLACE TRIGGER system.logon_deny
   AFTER LOGON
   ON DATABASE
DECLARE
BEGIN

   IF  DBMS_STANDARD.LOGIN_USER NOT IN   ('ORACLE',
           'REPORT_USER',
           'KPDBA1',
           'T039486',
           'Z995224',
           'SYSTEM',
           'SYS',
           'OUTLN',
           'DBSNMP',
           'IADS0000',
           'IA0000',
           'VCS_ADMIN',
           'DBAORA',
           'DBIMGR',
           'ORACLE',
           'OPRORA',
           'TSMSYS',
           'OLAPSYS',
           'XDB',
           'SCOTT',
           'CTXSYS',
           'DMSYS',
           'MDSYS',
           'WMSYS',
           'CTXSYS',
           'HR',
           'ORDSYS',
           'ANONYMOUS',
           'ORDPLUGINS',
           'DIP',
           'SYSMAN')
      AND ( TRIM(SYS_CONTEXT ('USERENV', 'SERVICE_NAME')) = TRIM(SYS_CONTEXT ('USERENV', 'DB_NAME') ) 
            OR TRIM(SYS_CONTEXT ('USERENV', 'SERVICE_NAME')) = 'SYS$USERS' )  
            -- SYS$USERS is the default service for user sessions that are not associated with services. 
   THEN
         INSERT INTO SYSTEM.LOGIN_LOG (USERNAME, SERVICE_NAME, DB_NAME,
                                    OSUSER,
                                    TERMINAL,
                                    IP,
                                    MODULE,
                                    LOGIN_TIME,
                                    HOST)
      VALUES (DBMS_STANDARD.LOGIN_USER,
            SYS_CONTEXT ('USERENV', 'SERVICE_NAME'),
            SYS_CONTEXT ('USERENV', 'DB_NAME'),
              SYS_CONTEXT ('USERENV', 'OS_USER'),
              SYS_CONTEXT ('USERENV', 'TERMINAL'),
              SYS_CONTEXT ('USERENV', 'IP_ADDRESS'),
              SYS_CONTEXT ('USERENV', 'MODULE'),
              SYSTIMESTAMP,
              SYS_CONTEXT ('USERENV', 'HOST')
              );

      COMMIT;
      RAISE_APPLICATION_ERROR (-20001, 'Unauthorized service name for this login. Please connect using your application''s assigned service name.');
   END IF;
END;
/