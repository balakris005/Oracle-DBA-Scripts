column inst_id format 999
column message_text format a100
column originating_timestamp format a40
break on inst_id skip 1 page
select inst_id,originating_timestamp, message_text
from 
table (gv$ (cursor 
	( 
select inst_id,message_text,originating_timestamp from V$DIAG_ALERT_EXT where component_id='rdbms' and message_text like '%ORA%' and originating_timestamp>sysdate-30
)
	))
order by 1,2;



column inst_id format 999
column message_text format a100
column originating_timestamp format a40
break on inst_id skip 1 page
select inst_id,originating_timestamp, message_text
from 
table (gv$ (cursor 
	( 
select inst_id,message_text,originating_timestamp from V$DIAG_ALERT_EXT where component_id='rdbms' and message_text like '%ORA%' and originating_timestamp>sysdate-1
)
	))
order by 1,2;
