
set line 1000
set pagesize 1000
break on inst_id skip 1 page
column inst_id format 999
column component_id format a15
column adr_home format a40
column min_timestamp format a40
column max_timestamp format a40
column cnt format 9999999

select 
	inst_id,component_id,ADR_HOME,min min_timestamp,max max_timestamp,cnt 
from 
	table (gv$ (cursor 
	( select 
		inst_id,component_id,ADR_HOME,min(ORIGINATING_TIMESTAMP)min,max(ORIGINATING_TIMESTAMP) max,count(1) CNT 
	  from 
          V$DIAG_ALERT_EXT 
	  group by inst_id,component_id,ADR_HOME
        )
	)) 
	order by 1,2,3;