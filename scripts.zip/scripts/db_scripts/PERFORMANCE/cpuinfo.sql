set pagesize 1000
SET MARKUP HTML ON SPOOL ON PREFORMAT OFF ENTMAP ON -
HEAD "<TITLE>KP - DAILY CHECK REPORT</TITLE> -
<STYLE type='text/css'> -
<!-- BODY {background:white;text-align:Left;font-family:times new roman;font-size:15px;border:1px solid black;font-weight:bold;color:orange} --> -
<!-- TH {background: #7598C0;color:#FFFFFF;font-family:verdana;font-size:10px;border:1px solid black;} --> -
<!-- TD {background: #F8FAFB;color:#000000;font-family:verdana;font-size:10px;border:1px solid lightgrey;text-align:justify;} --> -
<!-- TR {valign:top;} --> -
<!-- P {background: white;color:RED} --> -
</STYLE>" -
BODY "color='white'" -
TABLE "BORDER='0' cellspacing='1' cellpadding='1' width='100%' "
set feed off
spool cpuinfo.html


column 00 format a5
column 01 format a5
column 02 format a5
column 03 format a5
column 04 format a5
column 05 format a5
column 06 format a5
column 07 format a5
column 08 format a5
column 09 format a5
column 10 format a5
column 11 format a5
column 12 format a5
column 13 format a5
column 14 format a5
column 15 format a5
column 16 format a5
column 17 format a5
column 18 format a5
column 19 format a5
column 20 format a5
column 21 format a5
column 22 format a5
column 23 format a5

select 
	trunc(rollup_timestamp) dat,
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='00' then maximum end),1)) "00",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='01' then maximum end),1)) "01",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='02' then maximum end),1)) "02",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='03' then maximum end),1)) "03",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='04' then maximum end),1)) "04",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='05' then maximum end),1)) "05",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='06' then maximum end),1)) "06",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='07' then maximum end),1)) "07",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='08' then maximum end),1)) "08",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='09' then maximum end),1)) "09",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='10' then maximum end),1)) "10",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='11' then maximum end),1)) "11",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='12' then maximum end),1)) "12",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='13' then maximum end),1)) "13",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='14' then maximum end),1)) "14",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='15' then maximum end),1)) "15",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='16' then maximum end),1)) "16",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='17' then maximum end),1)) "17",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='18' then maximum end),1)) "18",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='19' then maximum end),1)) "19",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='20' then maximum end),1)) "20",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='21' then maximum end),1)) "21",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='22' then maximum end),1)) "22",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='23' then maximum end),1)) "23"
from
	MGMT$METRIC_HOURLY where target_name='nzapdb486.nndc.kp.org' and column_label='CPU Utilization (%)' 
group by trunc(rollup_timestamp)
order by 1;



select 
	trunc(rollup_timestamp) dat,
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='00' then maximum end),1)) "00",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='01' then maximum end),1)) "01",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='02' then maximum end),1)) "02",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='03' then maximum end),1)) "03",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='04' then maximum end),1)) "04",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='05' then maximum end),1)) "05",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='06' then maximum end),1)) "06",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='07' then maximum end),1)) "07",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='08' then maximum end),1)) "08",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='09' then maximum end),1)) "09",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='10' then maximum end),1)) "10",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='11' then maximum end),1)) "11",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='12' then maximum end),1)) "12",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='13' then maximum end),1)) "13",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='14' then maximum end),1)) "14",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='15' then maximum end),1)) "15",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='16' then maximum end),1)) "16",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='17' then maximum end),1)) "17",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='18' then maximum end),1)) "18",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='19' then maximum end),1)) "19",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='20' then maximum end),1)) "20",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='21' then maximum end),1)) "21",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='22' then maximum end),1)) "22",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='23' then maximum end),1)) "23"
from
	MGMT$METRIC_HOURLY where target_name='nzapdb487.nndc.kp.org' and column_label='CPU Utilization (%)' 
group by trunc(rollup_timestamp)
order by 1;


select 
	trunc(rollup_timestamp) dat,
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='00' then maximum end),1)) "00",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='01' then maximum end),1)) "01",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='02' then maximum end),1)) "02",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='03' then maximum end),1)) "03",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='04' then maximum end),1)) "04",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='05' then maximum end),1)) "05",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='06' then maximum end),1)) "06",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='07' then maximum end),1)) "07",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='08' then maximum end),1)) "08",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='09' then maximum end),1)) "09",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='10' then maximum end),1)) "10",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='11' then maximum end),1)) "11",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='12' then maximum end),1)) "12",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='13' then maximum end),1)) "13",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='14' then maximum end),1)) "14",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='15' then maximum end),1)) "15",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='16' then maximum end),1)) "16",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='17' then maximum end),1)) "17",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='18' then maximum end),1)) "18",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='19' then maximum end),1)) "19",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='20' then maximum end),1)) "20",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='21' then maximum end),1)) "21",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='22' then maximum end),1)) "22",
	to_char(round(sum(case when to_char(rollup_timestamp,'HH24')='23' then maximum end),1)) "23"
from
	MGMT$METRIC_HOURLY where target_name='nzapdb499.nndc.kp.org' and column_label='CPU Utilization (%)' 
group by trunc(rollup_timestamp)
order by 1;

spool off;
set markuphtml off;