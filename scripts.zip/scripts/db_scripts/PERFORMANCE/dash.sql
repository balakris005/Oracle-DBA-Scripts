set echo off;
--conn  c##cobi_arc/kaiser123@nzepdb003xm.nndc.kp.org:1521/SACRDSP2R.nndc.kp.org
conn DBAPEXREPORT/kaiser123@pzendb001xm.pldc.kp.org:1521/kpdbdash.pldc.kp.org
set sqlprompt dash>
set echo on;
set timing on;
set time on;
set history on
show con_name;
set line 10000