set line 1000
set pagesize 3000
column "PX_SERVERS_EXECS" heading "PARALLEL_SERVERS" format 999999999

column "buffer_gets" heading "MEMORY_READS|(in Million)" format 999999.99
column "disk_reads" heading "IO_READS|(in Million)" format 999999.99
column "elapsed_time" heading "DB_TIME|(in Hours)" format 999999.99
column "Cpu_time" heading "CPU_TIME|(in Hours)" format 999999.99
--column "elapsed_time" heading "DB_TIME|(in Minutes)" format 999999.99
--column "Cpu_time" heading "CPU_TIME|(in Minutes)" format 999999.99
column "executions" heading "EXECUTIONS" format 99999999999999.99
column "parse_calls" heading "PARSE_CALLS" format 99999999999999.99
column schema format a20
break on off

select
 trunc(b.begin_interval_time) dat,
 round(sum(ELAPSED_TIME_DELTA)/1000/1000/60/60,0) elapsed_time,
 round(sum(CPU_TIME_DELTA)/1000/1000/60/60,0) CPU_time,
 round(sum(BUFFER_GETS_DELTA)/1000/1000,2) "buffer_gets",
 round(sum(DISK_READS_DELTA)/1000/1000,2) "disk_reads",
 round(sum(rows_processed_DELTA),0) rows_processed,
 round(sum(executions_DELTA),0) executions,
 round(sum(PARSE_CALLS_DELTA),0) parse_calls,
 round(sum(PX_SERVERS_EXECS_DELTA),0) PX_SERVERS_EXECS
from
 DBA_HIST_SNAPSHOT B,
 DBA_HIST_SQLSTAT A
where
 a.snap_id=b.snap_id
and
 a.instance_number=b.instance_number
and
 trunc(b.begin_interval_time)>sysdate-90
group by trunc(b.begin_interval_time)
--,parsing_schema_name
 order by 1 desc,7 desc;
