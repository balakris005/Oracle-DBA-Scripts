set echo off;
conn c##t039486/bala111@szetdb002xm.ssdc.kp.org:1521/KPINSIGHT_SANWDIMED1R_USER.ssdc.kp.org
set sqlprompt DDIME>
set echo on;
set timing on;
set time on;
set history on
show con_name;
set line 10000