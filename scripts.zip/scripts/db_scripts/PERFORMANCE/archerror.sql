set pagesize 1000
column destination format a20
column error format a20
column status format a10
break on inst_id skip page

select dest_id,destination,binding,error,status,inst_id from gv$archive_dest where dest_id in (1,2,3,4,5,6,7,8,9,10)order by inst_id,dest_id;
show parameter state;
