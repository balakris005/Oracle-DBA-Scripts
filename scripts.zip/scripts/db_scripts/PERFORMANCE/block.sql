
column segment_name format a30
column segment_type format a15
column owner format a10
column tablespace_name a30
SELECT 
	owner,
	segment_name,
	segment_Type,
	tablespace_name,
	partition_name
FROM 
	dba_extents 
WHERE 
	file_id = &fn
and 
	&bn 
between 
	block_id 
AND 
	block_id + blocks - 1 ; 