alter session set NLS_DATE_FORMAT='DD-MON-YYYY';

set scan on
set pagesize 100
BREAK ON THREAD# SKIP 1
break on dest_id skip 1
ACCEPT VAL PROMPT 'Enter the number of past N days to review the Archive logs history :  '
select 
        -- Thread#,
	 dest_id,
         to_date(First_time,'DD-MON-YYYY')"DATE",
	min(sequence#),
	max(sequence#),
         count(1) "NUMBER OF LOGS",
         round((sum(blocks)*min(block_size))/1024/1024/1024,2) "SIZE (IN GB)"
from 
         v$archived_log 
where
         trunc(first_time)>trunc(sysdate-25)
group by 
--    Thread#,
	 dest_id,
         to_date(first_time,'DD-MON-YYYY') 
order by 
         1,2;
set scan on

alter session set NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS';