PROMPT
select * from 
(select round(sum(bytes)/1024/1024/1024,2) "DATA FILES" from dba_data_files) a,
(select round(sum(bytes)/1024/1024/1024,2) "DBA SEGMENTS" from dba_segments) b,
(select round(sum(bytes)/1024/1024/1024,2) "TEMP FILES" from dba_temp_files) c,
(select round(sum(bytes)/1024/1024/1024,2) "REDO FILES" from v$log) d,
(select round(sum(bytes)/1024/1024/1024,2) "STANDBY REDO" from v$standby_log) e;
PROMPT
PROMPT
