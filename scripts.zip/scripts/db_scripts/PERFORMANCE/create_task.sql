DECLARE
    my_task_name VARCHAR2(30);
BEGIN
    my_task_name := DBMS_SQLTUNE.CREATE_TUNING_TASK(
         sql_id => '&sql_id',
	 plan_hash_value => &plan_hash_value,
	 scope       => 'COMPREHENSIVE',
         time_limit  => &time_limit,
         task_name   => '&task_name',
         description => 'Task to tune a TDF query');
END;
/
