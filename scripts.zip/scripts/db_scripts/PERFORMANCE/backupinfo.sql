set pagesize 1000
set line 1000
column handle format a70
column SIZE_BYTES_DISPLAY format a10
column ORIGINAL_INPUT_BYTES_DISPLAY  format a10
column OUTPUT_BYTES_DISPLAY  format a10
column device_type format a8
alter session set NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS';
select 
	a.recid,
	b.recid,
--	a.set_stamp,
--	b.set_Stamp,
	b.backup_type,
	Decode(b.backup_type,'D','FULL','I','INCREMENTAL','L','ARCHIVE LOG'),
	decode(INCREMENTAL_LEVEL,'0','LEVEL 0','1','LEVEL 1') "INCRLVL",
--	b.set_count,
	b.start_time,
	b.completion_time,
	a.device_type,
a.size_bytes_display,
	b.ORIGINAL_INPUT_BYTES_DISPLAY,
	b.OUTPUT_BYTES_DISPLAY,
	a.handle,
	a.status,
	a.start_time,
	a.completion_time
	from 
	v$backup_piece_Details a, 
	v$backup_set_details b  
where 
--	b.bs_key=a.bs_key 
--and
	a.recid=b.recid
and 
	a.start_time> sysdate-15
and
	b.backup_type!='L'
--and 
--	a.handle like '%DB%' 
order by b.start_time;