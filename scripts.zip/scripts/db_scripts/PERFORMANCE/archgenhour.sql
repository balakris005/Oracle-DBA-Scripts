alter session set NLS_DATE_FORMAT='DD-MON-YYYY HH24';

set scan on
set pagesize 100
BREAK ON THREAD# SKIP 1
ACCEPT VAL PROMPT 'Enter the number of past N days to review the Archive logs history :  '
select 
         Thread#,
	 dest_id,
         to_date(First_time,'DD-MON-YYYY HH24')"DATE",
         count(1) "NUMBER OF LOGS",
         round((sum(blocks)*min(block_size))/1024/1024/1024,2) "SIZE (IN GB)"
from 
         v$archived_log 
where
         trunc(first_time)>trunc(sysdate-&VAL)
group by 
         Thread#,
	 dest_id,
         to_date(first_time,'DD-MON-YYYY HH24') 
order by 
         1,2;
set scan off