set echo off;
conn t039486/bala111@szetdb002xm.ssdc.kp.org:1521/DCRDS_SACRDSD1R.ssdc.kp.org
set sqlprompt DCRDS>
set echo on;
set timing on;
set time on;
set history on
show con_name;
set line 10000