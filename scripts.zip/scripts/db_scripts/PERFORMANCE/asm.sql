column "DISKGROUP NAME" format a15
break on inst_id
select 
--	inst_id,
	group_number,
	name "DISKGROUP NAME",
	State "STATE",
	Type,
	round(total_mb/1024,2) "TOTAL (GB)",
	round(free_mb/1024,2) "FREE (GB)",
	round(100-(free_mb/total_mb*100),2) "SPACE USAGE (%)" 
from 
	v$asm_diskgroup
order by 3,1;