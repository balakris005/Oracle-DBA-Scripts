#!/usr/bin/ksh
#
#set -x

if [ $# -ne 1 ]
then
  echo "Instance name needed as a parameter";
  exit
fi

export EMAIL='balakrishnan.jayasankar@kp.org'
export EMAIL1='balakrishnan.jayasankar@kp.org,vamsheedhar.r.katta@kp.org'

DATABASE=$1
. $HOME/bin/xdbenv $DATABASE >/dev/null
. /u01/app/oracle/dba/scripts/xdbenv $DATABASE >/dev/null

export LOG_DIR=/staging2/crds/pump/log
export LOG_FILE=acq_schemas_CDB061N22_full_EXP

$ORACLE_HOME/bin/expdp parfile=/u01/app/oracle/dba/scripts/crds_acq_weekly.par

chmod 777 /staging2/crds/pump/file/ACQ_SCHEMAS_WEEKLY_*

txt=`egrep 'error|ORA-|successfully' $LOG_DIR/$LOG_FILE.log`
if [[ $txt == *"error"* ]]; then
     cat $LOG_DIR/$LOG_FILE.log | expand | mailx -s "PCRDS ACQ Weekly backup failed - $DATABASE" $EMAIL
elif [[ $txt == *"ORA-"* ]]; then
    cat $LOG_DIR/$LOG_FILE.log | expand | mailx -s "PCRDS ACQ Weekly backup failed - $DATABASE" $EMAIL
elif [[ $txt == *"successfully"* ]]; then
    cat $LOG_DIR/$LOG_FILE.log | expand | mailx -s "PCRDS ACQ Weekly backup successfull - $DATABASE" $EMAIL1
fi

find $LOG_DIR/ -name "acq_schemas_CDB061N22_full*" -mtime +8 -exec rm {} \;

exit



---------------------------------------

nohup sh /u01/app/oracle/dba/scripts/crds_acq_weekly.sh CDB061N22  > /tmp/crds_acq_weekly_backup.log 2>&1 &

################################
#00 23 * * 5 sh /u01/app/oracle/dba/scripts/crds_acq_weekly.sh CDB061N22 > /tmp/crds_acq_weekly_backup.log 2>&1
