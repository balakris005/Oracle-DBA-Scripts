set lines 240 pages 5000 serveroutput on feedback on timing off verify off echo off long 50000
undefine ticket sql_id plan_id awr_packg

accept ticket      prompt "SNow Ticket: "
accept sql_id      prompt "Main SQL Id: "
accept sql_id_ref  prompt "SQL Id with good plan: "
accept plan_id     prompt "Good Plan Id: "
prompt

-- Load plan from AWR directly is possible after 12.2
set feedback off termout off
col awr_packg new_value awr_packg format a512
select case when to_number(substr(version,1,4)) >= 12.2 then q'['x := dbms_spm.load_plans_from_awr(begin_snap=>v_begin_snap,end_snap=>v_end_snap,basic_filter=>'sql_id = '''||v_sqlid||''' and plan_hash_value = '||v_tmp_planid||'',enabled=>'NO',fixed=>'NO');]'
            else q'[x := dbms_spm.load_plans_from_sqlset(sqlset_owner=>user,sqlset_name=> 'STS_'||v_ticket,enabled=>'NO',fixed=>'NO');]'
		end as awr_packg
from v$instance;

set feedback on termout on
declare
	v_ticket     varchar2(64) := '&ticket.';
	v_sqlid      varchar2(64) := '&&sql_id.';
	v_sqlid_ref  varchar2(64) := '&&sql_id_ref.';
	v_planid     number      := &&plan_id.;
	v_tmp_planid number;
	v_exact_sign number;
	v_temp_sign  number;
	v_force_sign number;
	v_begin_snap number;
	v_end_snap   number;
	v_sql_handle varchar2(64);
	v_plan_name  varchar2(64);
	v_temp_name  varchar2(64);
	c_explain    sys_refcursor;
	v_plan_table clob;
	v_sqltext    clob;
	x            pls_integer;
	v_version    float;
	v_cnt        number;
	c_load       sys_refcursor;
	v_sts        varchar2(64);
begin

	-- Check if SQL Baseline already exists
	select max(sql_handle),
	       max(plan_name)
	into v_sql_handle,
	     v_plan_name
	from dba_sql_plan_baselines
	where signature = (select exact_sign 
	                   from (select exact_matching_signature as exact_sign
	                         from gv$sqlarea
					         where sql_id = v_sqlid
					         union
					         select dbms_sqltune.sqltext_to_signature(sql_text=>sql_text,force_match=>0) as exact_sign
	                         from dba_hist_sqltext
					         where sql_id = v_sqlid
							)
					   where rownum < 2
					  );

	-- Raise error if SQL Baseline already exists
	if v_sql_handle is not null then
		raise_application_error(-20001,'SQL Baseline with SQL_Handle='||v_sql_handle||' and Plan_Name='||v_plan_name||' already exists...bye');
	end if;

	-- Get signature
	select max(exact_sign),
		   max(force_sign),
		   max(plan_hash_value)
	into v_exact_sign,
	     v_force_sign,
		 v_tmp_planid
	from (select exact_matching_signature as exact_sign,
	             force_matching_signature as force_sign,
				 plan_hash_value
          from gv$sqlarea
          where sql_id = v_sqlid
          union
          select dbms_sqltune.sqltext_to_signature(sql_text=>a.sql_text,force_match=>0) as exact_sign,
		         dbms_sqltune.sqltext_to_signature(sql_text=>a.sql_text,force_match=>1) as force_sign,
				 b.plan_hash_value
          from dba_hist_sqltext a,
		       dba_hist_sqlstat b
          where a.sql_id = b.sql_id
		    and a.sql_id = v_sqlid
		 );

	-- Raise error if SQL id and PLan id dont exist
	if v_exact_sign is null then
		raise_application_error(-20001,'Main SQL id '||v_sqlid||' doesnt exist...bye');
	end if;

	-- Check if good plan exists from cache
	select max(exact_matching_signature) as exact_sign
	into v_temp_sign
    from gv$sqlarea
    where sql_id = v_sqlid_ref
	  and plan_hash_value = v_planid;

	-- Raise error if SQL id and PLan id dont exist
	if v_temp_sign is null then
		raise_application_error(-20001,'Good Plan id '||v_planid||' for Referenced SQL id '||v_sqlid_ref||' doesnt exist on cache...bye');
	end if;

	-- Get SQL text
	select sql_text
	into v_sqltext
	from (select sql_fulltext as sql_text
		  from gv$sqlarea
		  where sql_id = v_sqlid
		  union all
		  select sql_text
		  from dba_hist_sqltext
		  where sql_id = v_sqlid
		 )
	where rownum < 2;

	-- Get range of snaps for main SQL id
	select max(snap_id)-1,
		   max(snap_id)
	into v_begin_snap,
		 v_end_snap 
	from dba_hist_sqlstat 
	where sql_id = v_sqlid
	  and plan_hash_value = v_tmp_planid;

	if v_end_snap is not null then
	
		-- Check version
		select to_number(substr(version,1,4))
		into v_version
		from v$instance;
	
		if v_version >= 12.2 then
		
			-- Create baseline from AWR 
			&awr_packg.
		else
			-- Check if SQL Tuning Set already exists
			select max(name) 
			into v_sts
			from dba_sqlset 
			where owner = user 
			  and name = 'STS_'||v_ticket;

			if v_sts > 0 then
				raise_application_error(-20001,'SQL Tuning Set '||v_sts||' already exists...bye');
			end if;

			-- Create SQL Tuning Set --
			dbms_sqltune.create_sqlset(sqlset_owner=>user,sqlset_name=>'STS_'||v_ticket,description=>'STS for SQL id '||v_sqlid||' plan hash value '||v_tmp_planid); 

			-- Check if SQL Tuning Set exists
			select max(name) 
			into v_sts
			from dba_sqlset 
			where owner = user 
			  and name = 'STS_'||v_ticket;

			if v_sts = 0 then
				raise_application_error(-20001,'Unable to create SQL Tuning Set...bye');
			else
				dbms_output.put_line('SQL Tuning Set '||v_sts||' successfully created');
			end if;

			-- Load plan from AWR into SQL Tuning Set
			open c_load for select value(p) from table(
				dbms_sqltune.select_workload_repository(begin_snap=>v_begin_snap,end_snap=>v_end_snap,basic_filter=>'sql_id = '''||v_sqlid||''' and plan_hash_value = '||v_tmp_planid||'',attribute_list=>'ALL')) p; 
				dbms_sqltune.load_sqlset(sqlset_owner=>user,sqlset_name=> 'STS_'||v_ticket, populate_cursor=>c_load); 
			close c_load;   

			-- Check if plan was loaded into SQL Tuning Set
			select count(*)
			into v_cnt
			from dba_sqlset_plans 
			where sqlset_owner = user 
			  and sqlset_name = 'STS_'||v_ticket;

			if v_cnt = 0 then
				raise_application_error(-20001,'Unable to load plan into SQL Tuning Set...bye');
			else
				dbms_output.put_line('Plan '||v_tmp_planid||' successfully loaded into SQL Tuning Set '||v_sts);
			end if;
			
			-- Create baseline from AWR 
			&awr_packg.
			
			-- Drop SQL Tuning Set --
			dbms_sqltune.drop_sqlset(sqlset_owner=>user,sqlset_name=>'STS_'||v_ticket);
			
			-- Check if SQL Tuning Set exists
			select max(name) 
			into v_sts
			from dba_sqlset 
			where owner = user 
			  and name = 'STS_'||v_ticket;

			if v_sts > 0 then
				raise_application_error(-20001,'Unable to drop SQL Tuning Set '||v_sts||'...bye');
			else
				dbms_output.put_line('SQL Tuning Set '||v_sts||' successfully dropped.');
			end if;

		end if;
	else
		-- Create baseline from cache
		x := dbms_spm.load_plans_from_cursor_cache(sql_id=>v_sqlid,plan_hash_value=>v_tmp_planid,enabled=>'NO',fixed=>'NO');
	end if;

	-- Check if temporary SQL baseline exists
	select max(sql_handle),
           max(plan_name)
	into v_sql_handle,
	     v_temp_name
	from dba_sql_plan_baselines
	where signature = v_exact_sign
	  and created >= sysdate-1/24/60
	  and enabled = 'NO'
	  and fixed = 'NO';

	if v_sql_handle is null then
		raise_application_error(-20001,'Unable to create temporary SQL Baseline...bye');
	else
		dbms_output.put_line('Temporary SQL Baseline with SQL_Handle='||v_sql_handle||' and Plan_Name='||v_temp_name||' successfully created.');
	end if;

	-- Create good baseline from cache
	x := dbms_spm.load_plans_from_cursor_cache(sql_handle=>v_sql_handle,sql_id=>v_sqlid_ref,plan_hash_value=>v_planid,enabled=>'YES',fixed=>'YES');

	-- Check if good SQL baseline exists
	select max(plan_name)
	into v_plan_name
	from dba_sql_plan_baselines
	where signature = v_exact_sign
	  and plan_name <> v_temp_name
	  and created >= sysdate-1/24/60
	  and enabled = 'YES'
	  and fixed = 'YES';

	if v_sql_handle is null then
		raise_application_error(-20001,'Unable to create SQL Baseline with good plan...bye');
	else
		dbms_output.put_line('SQL Baseline with SQL_Handle='||v_sql_handle||' and Plan_Name='||v_plan_name||' successfully created.');
	end if;
	  
	-- Rename plan
    x := dbms_spm.alter_sql_plan_baseline(sql_handle=>v_sql_handle,plan_name=>v_plan_name,attribute_name=>'PLAN_NAME',attribute_value=>'Baseline_'||v_sqlid); 

 	-- Check SQL baseline
	select max(plan_name)
	into v_plan_name
	from dba_sql_plan_baselines
	where signature = v_exact_sign
	  and sql_handle = v_sql_handle
	  and plan_name = 'Baseline_'||v_sqlid
	  and enabled = 'YES'
	  and fixed = 'YES';

	if v_sql_handle is null then
		raise_application_error(-20001,'Unable to rename SQL Baseline from '||v_plan_name||' to Baseline_'||v_sqlid||'...bye');
	else
		dbms_output.put_line('SQL Baseline successfully renamed to '||v_plan_name);
	end if;

	-- Add description --
	x := dbms_spm.alter_sql_plan_baseline(sql_handle=>v_sql_handle,plan_name=>v_plan_name,attribute_name=>'DESCRIPTION',attribute_value=>'Ticket:'||v_ticket||' sqlid:'||v_sqlid||' planid:'||v_planid||' ForceMatch:'||v_force_sign); 

	-- Drop temporary baseline with bad plan
	x := dbms_spm.drop_sql_plan_baseline(sql_handle=>v_sql_handle,plan_name=>v_temp_name);

 	-- Check SQL baseline
	select max(plan_name)
	into v_plan_name
	from dba_sql_plan_baselines
	where signature = v_exact_sign
	  and sql_handle = v_sql_handle
	  and plan_name = v_temp_name
	  and enabled = 'NO'
	  and fixed = 'NO';
	
	if v_plan_name is not null then
		raise_application_error(-20001,'Unable to drop temporary SQL Baseline with SQL_Handle='||v_sql_handle||' and Plan_Name='||v_temp_name);
	else
		dbms_output.put_line('Temporary SQL Baseline with SQL_Handle='||v_sql_handle||' and Plan_Name='||v_temp_name||' successfully dropped.'||chr(10));
	end if;

	-- Explain plan
	execute immediate 'explain plan set statement_id = ''MyPlan'' into plan_table for '||v_sqltext;
	open c_explain for select plan_table_output from table(dbms_xplan.display(table_name=>null,statement_id=>'MyPlan',format=>'typical -predicate +alias -projection +outline'));
		loop
			fetch c_explain into v_plan_table;
			exit when c_explain%notfound;
			dbms_output.put_line(v_plan_table);
		end loop;
	close c_explain;

-- exception handling
    exception
		when no_data_found then dbms_output.put_line('Error Code: '||sqlcode||' Error Message: no data found');
		when others        then dbms_output.put_line('Error Code: '||sqlcode||' Error Message: '||substr(sqlerrm,1,128));	  
end;
/
prompt
