set lines 240 pages 5000 serveroutput on feedback on timing off verify off echo off long 50000 define on
undefine ticket sql_id hints patch_packg

set feedback off termout off
col patch_packg new_value patch_packg format a512
select case when to_number(substr(version,1,4)) >= 12.2 then q'['x := dbms_sqldiag.create_sql_patch (sql_id=>v_sqlid,hint_text=>v_hints,name=>'Patch_'||v_sqlid,description=>'Ticket:'||v_ticket||' sqlid:'||v_sqlid||' ForceMatch:'||v_force_sign||' hints:'||substr(v_hints,1,256),category=>null,validate=>true);]'
            else q'[sys.dbms_sqldiag_internal.i_create_patch (sql_text=>v_sqltext,hint_text=>v_hints,name=>'Patch_'||v_sqlid,description=>'Ticket:'||v_ticket||' sqlid:'||v_sqlid||' ForceMatch:'||v_force_sign||' hints:'||substr(v_hints,1,256),category=>null,validate=>true);]'
		end as patch_packg
from v$instance;

set feedback on termout on
accept ticket      prompt "SNow Ticket: "
accept sql_id      prompt "SQL Id: "
accept hints       prompt "Hints: "
prompt

declare
	v_ticket     varchar(64) := '&ticket.';
	v_sqlid      varchar(64) := '&sql_id.';
	v_hints      clob        := q'[&hints.]';
	v_name       varchar(64);
	v_exact_sign number;
	v_force_sign number;
	c_load       sys_refcursor;
	c_explain    sys_refcursor;
	v_plan_table clob;
	v_sqltext    clob;
	x            clob;
begin

	-- Check if SQL Patch already exists
	select max(name)
	into v_name
	from dba_sql_patches
	where signature = (select exact_sign 
	                   from (select exact_matching_signature as exact_sign
	                         from gv$sqlarea
					         where sql_id = v_sqlid
					         union
					         select dbms_sqltune.sqltext_to_signature(sql_text=>sql_text,force_match=>0) as exact_sign
	                         from dba_hist_sqltext
					         where sql_id = v_sqlid
							)
					   where rownum < 2
					  );

	-- Raise error if SQL Patch if already exists
	if v_name is not null then
		raise_application_error(-20001,'SQL Patch '||v_name||' already exists...bye');
	end if;

	-- Get signature
	select max(exact_sign),
		   max(force_sign)
	into v_exact_sign,
	     v_force_sign
	from (select exact_matching_signature as exact_sign,
	             force_matching_signature as force_sign
          from gv$sqlarea
          where sql_id = v_sqlid
          union
          select dbms_sqltune.sqltext_to_signature(sql_text=>sql_text,force_match=>0) as exact_sign,
		         dbms_sqltune.sqltext_to_signature(sql_text=>sql_text,force_match=>1) as force_sign
          from dba_hist_sqltext
          where sql_id = v_sqlid
		 );

	-- Raise error if SQL id doesnt exist
	if v_exact_sign is null then
		raise_application_error(-20001,'SQL id '||v_sqlid||' doesnt exist...bye');
	end if;

	-- Get SQL text
	select sql_text
	into v_sqltext
	from (select sql_fulltext as sql_text
		  from gv$sqlarea
		  where sql_id = v_sqlid
		  union all
		  select sql_text
		  from dba_hist_sqltext
		  where sql_id = v_sqlid
		 )
	where rownum < 2;

	-- Create SQL Patch
	&patch_packg.

	-- Check if SQL Patch exists
	select max(name)
	into v_name
	from dba_sql_patches
    where name = 'Patch_'||v_sqlid
	  and signature = v_exact_sign
	  and created >= sysdate-1/24/60;

	if v_name is null then
		raise_application_error(-20001,'Unable to create SQL Patch...bye');
	else
		dbms_output.put_line('SQL Patch '||v_name||' successfully created'||chr(10));
	end if;

	-- Force match pending

	-- Explain plan
	execute immediate 'explain plan set statement_id = ''MyPlan'' into plan_table for '||v_sqltext;
	open c_explain for select plan_table_output from table(dbms_xplan.display(table_name=>null,statement_id=>'MyPlan',format=>'typical -predicate +alias -projection +outline'));
		loop
			fetch c_explain into v_plan_table;
			exit when c_explain%notfound;
			dbms_output.put_line(v_plan_table);
		end loop;
	close c_explain;

-- exception handling
    exception
		when no_data_found then dbms_output.put_line('Error Code: '||sqlcode||' Error Message: no data found');
		when others        then dbms_output.put_line('Error Code: '||sqlcode||' Error Message: '||substr(sqlerrm,1,128));	  
end;
/
prompt
