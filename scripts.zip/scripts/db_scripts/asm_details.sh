#!/usr/bin/ksh
## ##################################################################
##
##    Filename : asm_disk_validation.sh
##
##      Author : vinothkumar.bakthavachalam@kp.org
##
##        Date : 09/16/2016
##
## Description : This script will go through each and every ASM disk and validate Queue_Depth,Reserve_Policy,pvid and also provides the basic disk information.
##
######################################################################

function asm_details
{
cd /home/oracle/
export SID=`ps -ef | grep pmon | grep ASM | awk -Fpmon_ '{print $2}'`
export ORACLE_SID=$SID
export ORACLE_HOME=`grep $SID /etc/oratab | cut -d: -f2`
export PATH=$ORACLE_HOME/bin:$PATH
ct=$(date "+%Y.%m.%d-%H.%M.%S")
$ORACLE_HOME/bin/kfod status=TRUE disks=all dscvgroup=TRUE > Disk_details_$ct
export f_name=Disk_details_$ct
printf "=======================================================================================================================\n" > asm_disk_details_$ct
printf "%-22s | %-10s |%-15s | %-10s |%-11s | %-10s |%-4s | %-12s | %-10s\n "  Disk_Name Perm Owner size-MB Status DG Q_Depth Res_Policy pvid>> asm_disk_details_$ct
printf "=======================================================================================================================\n " >> asm_disk_details_$ct
for i in `cat $f_name | awk '{print $5}'| grep -v Disk`
do
ds=`cat $f_name | grep -w "$i" | awk '{print $4}'`
sz=`cat $f_name | grep -w "$i" | awk '{print $2}'`
dg=`cat $f_name | grep -w "$i" | awk '{print $6}'`
pr=`ls -tlr $i | awk '{print $1}'`
ow=`ls -tlr $i | awk '{print $3":"$4}'`
f=`echo $i | awk -F'/r' '{print $2}'`
qd=`lsattr -El $f | grep queue_depth | awk '{print $2}'`
rp=`lsattr -El $f  | grep reserve_policy | awk '{print $2}'`
pvid=`lsattr -El $f | grep pvid | grep -v pvid_takeover | awk '{print $2}'`
printf "%-21s | %-10s |%-15s | %-10s |%-11s | %-10s |%-7s | %-12s | %-10s\n " $i $pr $ow $sz $ds $dg $qd $rp $pvid >> asm_disk_details_$ct
done
}

function old_asm_details
{
cd /home/oracle/
f_check=`ls -tlr Disk_details* | wc -l`
if [ $f_check -gt 0 ];
then
old_f=`ls -ltr Disk_details* | grep Disk_details | grep -v grep | tail -1 | awk '{print $9}'`
export f_name=$old_f
ct=$(date "+%Y.%m.%d-%H.%M.%S")
printf "=======================================================================================================================\n" > asm_disk_details_$ct
printf "%-22s | %-10s |%-15s | %-10s |%-11s | %-10s |%-4s | %-12s | %-10s\n "  Disk_Name Perm Owner size-MB Status DG Q_Depth Res_Policy pvid>> asm_disk_details_$ct
printf "=======================================================================================================================\n " >> asm_disk_details_$ct
for i in `cat $f_name | awk '{print $5}'| grep -v Disk`
do
ds=`cat $f_name | grep -w "$i" | awk '{print $4}'`
sz=`cat $f_name | grep -w "$i" | awk '{print $2}'`
dg=`cat $f_name | grep -w "$i" | awk '{print $6}'`
pr=`ls -tlr $i | awk '{print $1}'`
ow=`ls -tlr $i | awk '{print $3":"$4}'`
f=`echo $i | awk -F'/r' '{print $2}'`
qd=`lsattr -El $f | grep queue_depth | awk '{print $2}'`
rp=`lsattr -El $f  | grep reserve_policy | awk '{print $2}'`
pvid=`lsattr -El $f | grep pvid | grep -v pvid_takeover | awk '{print $2}'`
printf "%-21s | %-10s |%-15s | %-10s |%-11s | %-10s |%-7s | %-12s | %-10s\n " $i $pr $ow $sz $ds $dg $qd $rp $pvid >> asm_disk_details_$ct
done
else
printf "There is no old disk information available to capture additional details"
fi
}
inst_chk=`ps -ef | grep pmon | grep ASM | wc -l`
if [ $inst_chk -gt 0 ];
then
asm_details
else
old_asm_details
fi

